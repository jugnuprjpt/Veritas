import React from "react";
import { Link } from "react-router-dom";

import { Tabs, Tab,Accordion,Item,Header,Body } from "react-bootstrap";


const HealthProposal = () => {
  return (
    <>
      <div className="container-fluid commoncl">
        <div className="row">
          <div className="col-12 health-reviewpage-bg pt-md-5 pb-md-3">
            <div className="container">
              <div className="row">
                <div className="col-md-6 col-xxl-8 whbg pt-md-3 pb-md-3 pl-xl-5 pr-xl-5 posch">
                  <div className="row justify-content-between align-items-center">
                    <div className="col">
                      <img
                        src="../img/comp-logo/adityabirla.png"
                        alt=""
                        className="img-fluid mb-3"
                      />
                    </div>
                    <div className="col text-right">
                      <div className="d-flex flex-column premiumamount">
                        <span className="orangetext"> Premium </span>
                        <span className="orangetext font-weight-semi-bold">
                          <i className="fas fa-rupee-sign mr-1"></i> 25000
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-12 ">
                      <p>
                        <strong> Policy Start Date : </strong> 12-Feb-2019
                      </p>
                      <p>
                        <strong> Policy End Date : </strong> 03-Feb-2021
                      </p>
                      <hr className="horizantalline" />
                      <p>
                        <strong> Quotation Number : </strong>{" "}
                        VTSBMTRPC2019070917335816
                      </p>
                      <p>
                        <strong> Vehicle Model : </strong> MARUTI SWIFT DZIRE
                        LXI (1298 cc) - PETROL
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

<div className="container fortab">
  <div className="row">
    <div class="col-12"> 
    </div>
  </div>
         <Tabs  fill       
        
        >
          <Tab
            eventKey={1}
            title="Proposal's Info"
            class="btn btn-outline-success"
          >
            <div className="container health-after-plan pt30 pb30 pl-0 pr-0 ">
              <div className="row no-gutters">
                <div className="col-12 bxcl pl-0 pr-0 ">
                  {/*  <uib-tabset active="active" justified="true" className="fortab"> </uib-tabset>
        <uib-tab index="0" heading="Proposer’s Info"> 
        </uib-tab> */}
                  <div className="forcard fortab">
                    <div className="p-3">
                      <h4 className="mb-3 orangetext">Personal Detail</h4>
                      <div className="border p-3 border-radius-10 mb-3">
                        <div className="row">
                          <div className="col-12 col-md-4">
                            <div className="row lesspd">
                              <div className="col-4 col-md-6 col-lg-5   ">
                                <div className="form-group">
                                  <label className="font-weight-bold">
                                    Salutation{" "}
                                    <sup className="text-danger">*</sup>
                                  </label>
                                  <select className="custom-select ">
                                    <option selected>Salutation</option>
                                  </select>
                                </div>
                              </div>
                              <div className="col-8  col-md-6 col-sm-8 col-lg-7 ">
                                <label className="font-weight-bold">
                                  First Name{" "}
                                  <sup className="text-danger">*</sup>{" "}
                                </label>
                                <div className="form-group">
                                  <input
                                    type="text"
                                    className="form-control floating-input"
                                    placeholder=" "
                                    />
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-md-4">
                            <label className="font-weight-bold">
                              Middle Name <sup className="text-danger">*</sup>{" "}
                            </label>
                            <div className="form-group">
                              <input
                                type="text"
                                className="form-control floating-input"
                                placeholder=" "
                                />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="font-weight-bold">
                                Last Name
                              </label>

                              <input
                                type="text"
                                className="form-control floating-input"
                                placeholder=" "
                                />
                            </div>
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-md-4">
                            <div className="row lesspd">
                              <div className="col-sm-6">
                                <div className="form-group">
                                  <label className="font-weight-bold">
                                    Gender
                                  </label>
                                  <select className="custom-select floating-select">
                                    <option selected>Select Gender</option>
                                  </select>
                                </div>
                              </div>
                              <div className="col-sm-6">
                                <div className="form-group">
                                  <label className="font-weight-bold">
                                    Marital Status
                                  </label>
                                  <select className="custom-select floating-select">
                                    <option selected>Marital Status</option>
                                  </select>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="mb-3">
                              <label className="font-weight-bold">
                                Birth Date
                              </label>
                              <div className="input-group  dateinput flex-nowrap">
                                <input
                                  type="text"
                                  className="form-control floating-input"
                                  placeholder=" "
                                  uib-datepicker-popup="{{format}}"
                                  ng-model="dt"
                                  is-open="popup1.opened"
                                  datepicker-options="dateOptions"
                                  ng-required="true"
                                  close-text="Close"
                                  alt-input-formats="altInputFormats"
                                />

                                <div className="input-group-append">
                                  {" "}
                                  <span
                                    className="input-group-text"
                                    ng-click="open1()"
                                  >
                                    <img src="img/dateicon.png" alt="" />
                                  </span>{" "}
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="font-weight-bold">
                                Occupation
                              </label>
                              <select className="custom-select">
                                <option selected>Service</option>
                              </select>
                            </div>
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="font-weight-bold">Email</label>
                              <input
                                type="text"
                                className="form-control "
                                placeholder=" "
                              />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="font-weight-bold">
                                Mobile Number
                              </label>
                              <input
                                type="text"
                                className="form-control "
                                placeholder=""
                              />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="font-weight-bold">
                                Additional Contact Number
                              </label>
                              <input
                                type="text"
                                className="form-control "
                                placeholder=" "
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                      <h4 className="mb-3 orangetext">Address Detail</h4>

                      <div className="border p-3 border-radius-10 mb-3">
                        <div className="row">
                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="font-weight-bold">
                                Address 1
                              </label>
                              <input
                                type="text"
                                className="form-control "
                                placeholder=" "
                              />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="font-weight-bold">
                                Address 2
                              </label>
                              <input
                                type="text"
                                className="form-control "
                                placeholder=" "
                              />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="font-weight-bold">
                                Address 3
                              </label>
                              <input
                                type="text"
                                className="form-control "
                                placeholder=" "
                              />
                            </div>
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="font-weight-bold">
                                Select State
                              </label>
                              <select className="custom-select">
                                <option selected>Select State</option>
                              </select>
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="font-weight-bold">
                                Select City
                              </label>
                              <select className="custom-select">
                                <option selected>Select City</option>
                              </select>
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="font-weight-bold">
                                Pincode
                              </label>
                              <input
                                type="text"
                                className="form-control "
                                placeholder=" "
                              />
                            </div>
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="font-weight-bold">
                                Pan Card{" "}
                              </label>
                              <input
                                type="text"
                                className="form-control "
                                placeholder=" "
                              />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <label className="font-weight-bold"> GSTIN </label>
                            <div className="form-group">
                              <input
                                type="text"
                                className="form-control "
                                placeholder="GSTIN"
                              />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="font-weight-bold">
                                {" "}
                                Aadhaar No.{" "}
                              </label>
                              <input
                                type="text"
                                className="form-control "
                                placeholder=" "
                              />
                            </div>
                          </div>

                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="font-weight-bold">
                                {" "}
                                Fasttag{" "}
                                <small>
                                  {" "}
                                  <strong> (Mandatory for Digit) </strong>{" "}
                                </small>{" "}
                              </label>
                              <input
                                type="text"
                                className="form-control "
                                placeholder=" "
                              />
                              <small>
                                {" "}
                                <strong> (Mandatory for Digit) </strong>{" "}
                              </small>
                            </div>
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-12">
                            <p>
                              <strong>
                                Registration address is same as above.
                              </strong>
                            </p>
                            <div className="pb-2">
                              <div className="custom-control custom-radio custom-control-inline">
                                <input
                                  type="radio"
                                  className="custom-control-input"
                                  name="customRadio"
                                  id="customRadio11"
                                />
                                <label
                                  className="custom-control-label"
                                  for="customRadio11"
                                >
                                  Yes
                                </label>
                              </div>
                              <div className="custom-control custom-radio custom-control-inline">
                                <input
                                  type="radio"
                                  className="custom-control-input"
                                  name="customRadio"
                                  id="customRadio22"
                                  checked
                                />
                                <label
                                  className="custom-control-label"
                                  for="customRadio22"
                                >
                                  No
                                </label>
                              </div>
                            </div>
                          </div>
                        </div>{" "}
                      </div>
                    </div>
                    <div className="pt10 pb15 text-center position-relative">
                      <a href="#">
                        <img
                          src="../img/back.png"
                          alt=" "
                          className="img-fluid backbtn"
                        />
                      </a>
                      <Link to="/Health/HealthRaviewPay">
                        <a href="#" className="btn orangebtn bigbutton">
                          <span className="next">Next</span>
                        </a>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Tab>

         {/*  ---------Insured Members------------------ */}


          <Tab 
            eventKey={2}
            title="Insured Members"
            class="btn btn-outline-success"
          >
           <div className="container health-after-plan pt30 pb30 pl-0 pr-0 ">
              <div className="row no-gutters">
                <div className="col-12 bxcl pl-0 pr-0 ">
                  {/*  <uib-tabset active="active" justified="true" className="fortab"> </uib-tabset>
        <uib-tab index="0" heading="Proposer’s Info"> 
        </uib-tab> */}
                  <div className="forcard fortab">
                    <div className="p-3">
                     
                      <div className="border p-3 border-radius-10 mb-3">
                        <div className="row">
                          <div className="col-12 col-md-4">
                            <div className="row lesspd">
                              <div className="col-4 col-md-6 col-lg-5   ">
                                <div className="form-group">
                                  <label className="font-weight-bold">
                                    Relation{" "}
                                    <sup className="text-danger">*</sup>
                                  </label>
                                  <select className="custom-select ">
                                    <option selected>Salutation</option>
                                  </select>
                                </div>
                              </div>
                              <div className="col-4 col-md-6 col-lg-5   ">
                                <div className="form-group">
                                  <label className="font-weight-bold">
                                    Salutation{" "}
                                    <sup className="text-danger">*</sup>
                                  </label>
                                  <select className="custom-select ">
                                    <option selected>Salutation</option>
                                  </select>
                                </div>
                              </div>
                              
                              <div className="col-8 col-md-6 col-sm-8 col-lg-7 ">
                                <label className="font-weight-bold">
                                  Last Name{" "}
                                  <sup className="text-danger">*</sup>{" "}
                                </label>
                                <div className="form-group">
                                  <input
                                    type="text"
                                    className="form-control floating-input"
                                    placeholder=" "
                                    />
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          <div className="col-md-4 col-sm-8">
                            <label className="font-weight-bold">
                              First Name <sup className="text-danger">*</sup>{" "}
                            </label>
                            <div className="form-group">
                              <input
                                type="text"
                                className="form-control floating-input"
                                placeholder=" "
                                />
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="font-weight-bold">
                                Middile Name
                              </label>

                              <input
                                type="text"
                                className="form-control floating-input"
                                placeholder=" "
                                />
                            </div>
                          </div>
                        </div>
                        
                        <div className="row">
                          <div className="col-md-4">
                            <div className="row lesspd">
                              <div className="col-sm-6">
                                <div className="form-group">
                                  <label className="font-weight-bold">
                                    Gender
                                  </label>
                                  <select className="custom-select floating-select">
                                    <option selected>Select Gender</option>
                                  </select>
                                </div>
                              </div>
                              <div className="col-sm-6">
                                <div className="form-group">
                                  <label className="font-weight-bold">
                                    Marital Status
                                  </label>
                                  <select className="custom-select floating-select">
                                    <option selected>Marital Status</option>
                                  </select>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="mb-3">
                              <label className="font-weight-bold">
                                Birth Date
                              </label>
                              <div className="input-group dateinput flex-nowrap">
                                <input
                                  type="text"
                                  className="form-control floating-input"
                                  placeholder=" "
                                  uib-datepicker-popup="{{format}}"
                                  ng-model="dt"
                                  is-open="popup1.opened"
                                  datepicker-options="dateOptions"
                                  ng-required="true"
                                  close-text="Close"
                                  alt-input-formats="altInputFormats"
                                />

                                <div className="input-group-append">
                                  {" "}
                                  <span
                                    className="input-group-text"
                                    ng-click="open1()"
                                  >
                                    <img src="img/dateicon.png" alt="" />
                                  </span>{" "}
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="font-weight-bold">
                                Occupation
                              </label>
                              <select className="custom-select">
                                <option selected>Service</option>
                              </select>
                            </div>
                          </div>
                        </div>
                       
                      
                        
                        </div>
                      </div>
                    
                    </div>
                    <div className="pt10 pb15 text-center position-relative">
                      <a href="#">
                        <img
                          src="../img/back.png"
                          alt=" "
                          className="img-fluid backbtn"
                        />
                      </a>
                      <Link to="/HealthRaviewPay">
                        <a href="#" className="btn orangebtn bigbutton">
                          <span className="next">Next</span>
                        </a>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>

             {/*  -----Nominine detail---------- */}
           
            <div className="container health-after-plan pt30 pb30 pl-0 pr-0 ">
              <div className="row no-gutters">
                <div className="col-12 bxcl pl-0 pr-0">

{/* <uib-tab index="1" heading="Insured Members"> */}
              <div class="forcard">
                <div class="p-3">

                  <div class="border p-3 border-radius-10">

                    <Accordion close-others="oneAtATime" class="accordiancl" defaultActiveKey={['0','1']} alwaysOpen>
                    <Accordion.Item eventKey="0">
                      
                      <div uib-accordion-group class="panel-default" ng-init="status.open = true" is-open="status.open">
                            <Accordion.Header> title 1 <i class="pull-right fa ico" ng-class="{'fa-minus': status.open, 'fa-plus': !status.open}"></i> </Accordion.Header>
                            <Accordion.Body>

                            <div class="row">
                          <div class="col-md-4">
                                <div class="form-group">
                              <input type="text" class="form-control " placeholder="Pan Card Number"/>
                            </div>
                              </div>
                          <div class="col-md-4">
                                <div class="form-group">
                              <input type="text" class="form-control " placeholder="GSTIN"/>
                            </div>
                              </div>
                          <div class="col-md-4">
                                <div class="form-group">
                              <input type="text" class="form-control " placeholder="Aadhaar No."/>
                            </div>
                              </div>
                        </div>
                            <div class="row">
                          <div class="col-md-4">
                                <div class="form-group">
                              <input type="text" class="form-control " placeholder="Pan Card Number"/>
                            </div>
                              </div>
                          <div class="col-md-4">
                                <div class="form-group">
                              <input type="text" class="form-control " placeholder="GSTIN"/>
                            </div>
                              </div>
                          <div class="col-md-4">
                                <div class="form-group">
                              <input type="text" class="form-control " placeholder="Aadhaar No."/>
                            </div>
                              </div>
                        </div>
                            </Accordion.Body>
                          </div>
                    </Accordion.Item>
                    <Accordion.Item eventKey="1">
                      <div uib-accordion-group class="panel-default" is-open="status2.open">
                            <Accordion.Header> title2 <i class="pull-right fa ico" ng-class="{'fa-minus': status2.open, 'fa-plus': !status2.open}"></i> </Accordion.Header>
                            <Accordion.Body>
                            <div class="row">
                          <div class="col-md-4">
                                <div class="form-group">
                              <input type="text" class="form-control " placeholder="Pan Card Number"/>
                            </div>
                              </div>
                          <div class="col-md-4">
                                <div class="form-group">
                              <input type="text" class="form-control " placeholder="GSTIN"/>
                            </div>
                              </div>
                          <div class="col-md-4">
                                <div class="form-group">
                              <input type="text" class="form-control " placeholder="Aadhaar No."/>
                            </div>
                              </div>
                        </div>
                        </Accordion.Body>
                          </div>
                          </Accordion.Item>  

                    </Accordion> 	

                  <div class="row">
                    <div class="col-md-4">
                      <div class="form-group">
                        <label class="font-weight-bold"> Vehicle Number </label>
                        <input type="text" class="form-control " placeholder=" " />
                      </div>
                    </div>
                    <div class="col-md-4">
                      <label class="font-weight-bold"> Registration Date </label>

                      <div class="input-group mb-3 dateinput">
                        <input type="text" class="form-control" placeholder="Date"/>
                        <div class="input-group-append"> <span class="input-group-text"><img src="img/dateicon.png"
                              alt="" /></span> </div>
                      </div>
                    </div>
                  </div>
                  <div class="row gridview">
                    <div class="col-md-4">
                      <div class="form-group">
                        <label class="font-weight-bold"> Customer Type</label>
                        <select class="custom-select">
                          <option selected>Customer Type</option>

                        </select>
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label class="font-weight-bold"> Engine Number</label>
                        <input type="text" class="form-control " placeholder=" " />
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label class="font-weight-bold">Chasis Number</label>
                        <input type="text" class="form-control " placeholder=" " />
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label class="font-weight-bold">Aadhaar No.</label>
                        <input type="text" class="form-control " placeholder=" " />
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-auto">

                      <strong>Hypothecation?</strong>

                    </div>

                    <div class="col-auto">
                      <div class="pb-2">
                        <div class="custom-control custom-radio custom-control-inline">
                          <input type="radio" class="custom-control-input" name="customRadio" id="customRadio111"/>
                          <label class="custom-control-label" for="customRadio111">Yes</label>
                        </div>
                        <div class="custom-control custom-radio custom-control-inline">
                          <input type="radio" class="custom-control-input" name="customRadio" id="customRadio222"
                            checked/>
                          <label class="custom-control-label" for="customRadio222">No</label>
                        </div>
                      </div>
                    </div>

                  </div> </div>
                  <div class="row">
                    <div class="col-md-4">
                      <div class="form-group">
                        <input type="text" class="form-control " placeholder="Financier Name" />
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <select class="custom-select">
                          <option selected>Low to High</option>
                          <option value="1">Boots</option>
                          <option value="2">Shoes</option>
                          <option value="3">Feet</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="d-flex align-center pt10 pb15">
                  <a href="#" class="btn orangebtn ml-auto mr-auto bigbutton"><span class="next">Next</span> </a>
                </div>
              </div>
            {/* </uib-tab> */}




                </div>
              </div>
            </div>
          </Tab>
          <Tab
            eventKey={3}
            title="Medical History"
            class="btn btn-outline-success"
          >
            <div className="container health-after-plan pt30 pb30 pl-0 pr-0 ">
              <div className="row no-gutters">
                <div className="col-12 bxcl pl-0 pr-0">

                <uib-tab index="2" heading="Medical History">
              <div class="forcard">
                <div class="p-3">
                  <div class="text-right d-flex justify-content-end ">
                    <div class="custom-control custom-checkbox mb-3">
                      <input type="checkbox" class="custom-control-input" id="customCheck111"
                        ng-model="ShowPassport1" />
                      <label class="custom-control-label" for="customCheck111">Check All</label>
                    </div>
                  </div>
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                      <tr>
                        <th>Questions</th>
                        <th width="200px">Self</th>

                      </tr>
                      <tr>
                        <td>Any pre-existing illness for the insured that needs to be declared.</td>
                        <td>
                          <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" name="customRadio" id="customRadio10"/>
                            <label class="custom-control-label" for="customRadio10">Yes</label>
                          </div>
                          <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" name="customRadio" id="customRadio20"
                              checked/>
                            <label class="custom-control-label" for="customRadio20">No</label>
                          </div>
                        </td>

                      </tr>
                      <tr>
                        <td>- If yes, please specify</td>
                        <td>
                          <textarea row="2" class="form-control">sdfsf </textarea>
                        </td>

                      </tr>
                      <tr>
                        <td>Is the insured taking any drugs for treatment ?</td>
                        <td>
                          <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" name="customRadio" id="customRadio10"/>
                            <label class="custom-control-label" for="customRadio10">Yes</label>
                          </div>
                          <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" name="customRadio" id="customRadio20"
                              checked/>
                            <label class="custom-control-label" for="customRadio20">No</label>
                          </div>
                        </td>

                      </tr>

                      <tr>
                        <td>Number of years the insured is suffering from Diabetes.</td>
                        <td>
                          <textarea row="2" class="form-control">sdfsf </textarea>
                        </td>

                      </tr>

                      <tr>
                        <td>What is your social status?</td>
                        <td>
                          <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" name="customRadio" id="customRadio10"/>
                            <label class="custom-control-label" for="customRadio10">Yes</label>
                          </div>
                          <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" name="customRadio" id="customRadio20"
                              checked/>
                            <label class="custom-control-label" for="customRadio20">No</label>
                          </div>
                        </td>

                      </tr>

                      <tr>
                        <td>Is insured having any eye problems ?</td>
                        <td>
                          <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" name="customRadio" id="customRadio10"/>
                            <label class="custom-control-label" for="customRadio10">Yes</label>
                          </div>
                          <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" name="customRadio" id="customRadio20"
                              checked/>
                            <label class="custom-control-label" for="customRadio20">No</label>
                          </div>
                        </td>

                      </tr>

                    </table>
                  </div>

                </div>
                <div class="d-flex align-center pt10 pb15">
                  <a href="#" class="btn orangebtn ml-auto mr-auto bigbutton"><span class="next">Next</span> </a>
                </div>
              </div>
            </uib-tab>


                </div>
                </div>
                </div>
            
          </Tab>
          <Tab
            eventKey={4}
            title="Other Details"
            class="btn btn-outline-success"
          >
            <div className="container health-after-plan pt30 pb30 pl-0 pr-0 ">
              <div className="row no-gutters">
                <div className="col-12 bxcl pl-0 pr-0">

                {/* <uib-tab index="3" heading="Other Details"> */}

<div class="forcard">
  <div class="p-3">

    <h4 class="mb-3 orangetext">Mandatory terms & conditions</h4>
    <div class="row">
      <div class="col-12">                      
        <p><strong>I hereby confirm </strong></p>
        <ul class="disc">
          <li>The declarations made here with are true & correct.</li>
          <li>Appointment of Manas Insurance Brokers Pvt. Ltd. as my insurance Broker & authorise
            them to represent me to insurance companies/agencies for my insurance needs.
          </li>
        </ul>


        <div class="pb-2 pt-2">
          <div class="custom-control custom-radio custom-control-inline">
            <input type="radio" class="custom-control-input" name="customRadio" id="customRadio11"/>
            <label class="custom-control-label" for="customRadio11">Yes</label>
          </div>
          <div class="custom-control custom-radio custom-control-inline">
            <input type="radio" class="custom-control-input" name="customRadio" id="customRadio22"
              checked=""/>
            <label class="custom-control-label" for="customRadio22">No</label>
          </div>
        </div>

        <p class="mt-2"><strong>Do you wish to receive only soft copy? </strong></p>

        <div class="custom-control custom-radio mb-2">
          <input type="radio" id="customRadio2" name="customRadio" class="custom-control-input"/>
          <label class="custom-control-label" for="customRadio2">I don't want the hard copy of the
            policy. i’m tree-lover & will help save paper by having soft copy only</label>
        </div>

        <div class="custom-control custom-radio mb-2">
          <input type="radio" id="customRadio3" name="customRadio" class="custom-control-input"/>
          <label class="custom-control-label" for="customRadio3">No</label>
        </div>

      </div>
    </div>

    <div class="d-flex align-center pt10 pb15">
      <a href="#" class="btn orangebtn ml-auto mr-auto bigbutton"><span class="next">Next</span> </a>
    </div>

    </div>
    </div>

{/* </uib-tab> */}


                </div>
                </div>
                </div>
          </Tab>
        </Tabs>
</div>
 

     
      </div>
    </>
  );
};

export default HealthProposal;
