import React, { useState } from "react";

const Individualbtn = () => {
  const [active, setActive] = useState("");

  const handleClick = (event) => {
    setActive(event.target.id);
  };

  return (
    <>
      <div className="individualbtn">
        <button
          key={1}
          className={
            active === "1"
              ? "btn self-individual active p-1"
              : "btn self-individual p-1"
          }
          id={"1"}
          onClick={handleClick}
        >
          Self
        </button>

        <button
          key={2}
          className={
            active === "2" ? "btn spouse active p-1" : "btn spouse p-1"
          }
          id={"2"}
          onClick={handleClick}
        >
          Spouse
        </button>

        <button
          key={3}
          className={
            active === "3" ? "btn father active p-1" : "btn father p-1"
          }
          id={"3"}
          onClick={handleClick}
        >
          Father
        </button>

        <button
          key={4}
          className={
            active === "4" ? "btn mother active p-1" : "btn mother p-1"
          }
          id={"4"}
          onClick={handleClick}
        >
          Mother
        </button>

        <button
          key={5}
          className={active === "5" ? "btn son active p-1" : "btn son p-1"}
          id={"5"}
          onClick={handleClick}
        >
          Son
        </button>

        <button
          key={6}
          className={
            active === "6" ? "btn daughter active p-1" : "btn daughter p-1"
          }
          id={"6"}
          onClick={handleClick}
        >
          Daughter
        </button>
      </div>
    </>
  );
};

export default Individualbtn;
