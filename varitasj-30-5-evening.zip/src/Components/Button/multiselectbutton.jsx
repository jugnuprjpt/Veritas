import React, { Component } from "react";
import DatePickerFamily from "../DatePickerFamily/DatePickerFamily";

const BUTTONS = [
  { id: 0, title: "Self", class: "self-individual" },
  { id: 1, title: "Father", class: "father" },
  { id: 2, title: "Spouse", class: "spouse" },
  { id: 3, title: "Mother", class: "mother" },
  { id: 4, title: "Son", class: "son" },
  { id: 5, title: "Daughter", class: "daughter" },
];

class Map extends Component {
  constructor(props) {
    super(props);
    this.state = {
      values: [],
    };
  }
  handleButton = (button) => {
    let tmp = this.state.values;
    if (this.state.values.includes(button)) {
      this.setState({
        values: this.state.values.filter((el) => el !== button),
      });
    } else {
      tmp.push(button);
      this.setState({
        values: tmp,
      });
    }
  };

  render() {
    return (
      <div class="container">
        <div className="familypage card-body">
          <div className="row gridview">
            {BUTTONS.map((bt) => (
              <div className="col-12 col-md">
                <div className="row lesspd">
                  <div className="col-auto">
                    <button
                      key={bt.id}
                      onClick={() => this.handleButton(bt.id)}
                      className={
                        this.state.values.includes(bt.id)
                          ? bt.class + " " + "familybtnscl active"
                          : bt.class + " " + "familybtnscl"
                      }
                    >
                      <span> {bt.title} </span>
                    </button>
                  </div>
                  <div className="col col-lg-auto">
                    <DatePickerFamily></DatePickerFamily>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }
}

export default Map;
