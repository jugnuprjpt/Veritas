import React from 'react'
import {Outlet} from 'react-router'
import Main from '../Main/Main.jsx'



const Health = () => {
  return (
    <>
    <Main></Main>
    <Outlet></Outlet>
    
    </>
  )
}

export default Health
