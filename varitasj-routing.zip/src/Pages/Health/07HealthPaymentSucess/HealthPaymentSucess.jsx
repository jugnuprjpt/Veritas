import React from 'react'

const HealthPaymentSucess = () => {
  return (
    <>
    
  <div class="container-fluid commoncl ">
    <div class="container pt50 pb50 payment-success">
      <div class="row">
        <div class="col-md-10 offset-md-1  col-lg-8 offset-lg-2  payment-success shadow">
          <div class="row align-center justify-content-center">
            <div class="col-auto text-center pt15"> 
              <img src="img/payment-success.png" alt=" " class="img-fluid" />
              
            </div>

            <div class="col-12 text-center">
              <h4 class="pt15 pb15 successtext font-weight-bold d-inline-block ">Payment Success!</h4>
            </div>

            

          </div>

          <div class="row">
            <div class="col text-center font-weight-bold p-4 pb-4">
              Thank you for choosing Policy Bonanza Insurance for your insurance requirement.

            </div>
          </div>

          <div class="row">
            <div class="col-12  greybg ">
              <div class="row">
                <div class="col-12 d-flex flex-wrap policytitle pt5 pb5 justify-content-between align-items-center"> <strong class="text-nowrap" >Policy Details</strong> <img
                    src="img/comp-logo/ltgic.png" class="img-responsive" alt="" /> </div>
              </div>
              <hr />
              <div class="row">
                <div class="col-md-6 pt10 pb10"><strong>Quotation Number:</strong>
                  <span>VTSBMTRPC2019070917335816</span></div>
                <div class="col-md-6 pt10 pb10"><strong>Transaction Number: </strong> <span> PRA123456 </span></div>
              </div>
              <hr />
              <div class="row">
                <div class="col-md-6 pt10 pb10"><strong>Your Premium:</strong> <span>2834</span></div>
                <div class="col-md-6 pt10 pb10"><strong>Status: </strong> <span> Success</span></div>
              </div>
              <hr />
              <div class="row">
                <div class="col-12 pt10 pb10"><strong>Policy Number:</strong> <span>OG-19--1901-1825-00000058</span>
                </div>
              </div>
              <hr />
              <div class="row">
                <div class="col-12 pt15 pb15 text-center"> <a href="#" class="btn orangebtn"> Download Policy </a>
                  <p class="pt10">We have sent an email to <a href="mailto:email@email.com" class="bodytext font-weight-bold" >email@email.com</a> with the
                    transaction details and copy of the Policy document </p>


                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-12">
          <h4 class="text-center pt10"> <a class="feedbacklink" href="#" ><strong> Give us your valuable feedback </strong></a> </h4>
          <form  class="ng-pristine ng-valid">
                <div class="form-group mt15">
              <textarea class="form-control" rows="4"></textarea>
            </div>
                <div class="mb15 text-center">
              <button class="btn orangebtn">Submit</button>
            </div>
              </form>
        </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  {/* -------------------------------Payment failed----------------------------------- */}
    
  <div class="container-fluid commoncl ">
    <div class="container pt50 pb50 payment-success">
      <div class="row">
        <div class="col-12 col-md-10 offset-md-1  col-lg-8 offset-lg-2  payment-success shadow">
          <div class="row align-center justify-content-center">
            <div class="col-auto text-center pt15">
              <img src="img/payment-fail.png" alt="" class="img-fluid" />

            </div>

            <div class="col-12 text-center">
              <h4 class="pt15 pb15 failtext font-weight-bold d-inline-block ">Payment Fail!</h4>
            </div>



          </div>



          <div class="row">
            <div class="col-12  greybg ">


              <div class="row">
                <div class="col-md-6 pt10 pb10"><strong>Quotation Number:</strong>
                  <span>VTSBMTRPC2019070917335816</span>
                </div>
                <div class="col-md-6 pt10 pb10"><strong>Transaction Number: </strong> <span> PRA123456 </span></div>
              </div>
              <hr />
              <div class="row">
                <div class="col-md-6 pt10 pb10"><strong>Your Premium:</strong> <span>2834</span></div>
                <div class="col-md-6 pt10 pb10"><strong>Status: </strong> <span> Failure</span></div>
              </div>
              <hr />


              <div class="row">
                <div class="col-12 pt15 pb15 text-center">
                  <p class="pt10">We have sent an email to <a href="mailto:email@email.com"
                      class="bodytext font-weight-bold">email@email.com</a> with the
                    transaction details and copy of the Policy document </p>


                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-12">
              <h4 class="text-center pt10"> <a class="feedbacklink" href="#"><strong> Give us your valuable feedback
                  </strong></a> </h4>
              <form class="ng-pristine ng-valid">
                <div class="form-group mt15">
                  <textarea class="form-control" rows="4"></textarea>
                </div>
                <div class="mb15 text-center">
                  <button class="btn orangebtn">Submit</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
    </>
  )
}

export default HealthPaymentSucess