import React from "react";
import { useState } from "react";
import ButtonGroup from "../../../Components/Button/ButtonGroup";

import { Link } from "react-router-dom";

const HealthInsurance = () => {
  const [active, setActive] = useState("");

  const handleClick = (event) => {
    setActive(event.target.id);
  };

  const printButtonLabel = (event) => {
    console.log(event.target.name);
  }
  return (
    <>
   
      <div className="container-fluid commoncl healthbg healthdiv d-flex align-items-center justify-content-center ">
        <div className="row flex-grow-1">
          <div className="col-12">
            <div className="container ">
              <div className="row">
                <div className="col-12 col-xl-10 offset-xl-1 ">
                  <div className="card commoncard">
                    <div className="card-header d-flex justify-content-center align-items-center">
                      <a href="#" className="backbutton">
                        <i className="fas fa-angle-double-left whtext"></i>{" "}
                        <span className="d-none d-md-inline-block">Back </span>
                      </a>
                      <h1>Health Insurance </h1>
                      <img
                        src="../img/logo-wh.png"
                        alt=" "
                        className="img-fluid whitelogo"
                      />
                    </div>
                    
                    <div className="card-body" ng-show="ShowTab">
                      <div className="row">
                        <div className="col-12 d-flex justify-content-center align-items-center">
                          <div className="btn-group btngp mb-3 btngroup text-center">
                            <ButtonGroup
                            buttons={["Individual", " Family Floater"]}
                            doSomethingAfterClick={printButtonLabel}
                              className="btn   mb-0"
                              ng-model="radioModel"
                              uib-btn-radio="'Left'"
                              uncheckable
                            >
                             
                            </ButtonGroup>
                           
       {/*                      <div className='btngroup text-center'>
    <ButtonGroup
        buttons={["One", "Two"]}
        doSomethingAfterClick={printButtonLabel}
      />
      </div> */}
                           {/*  <label
                              className="btn   mb-0"
                              ng-model="radioModel"
                              uib-btn-radio="'Middle'"
                              uncheckable
                            >
                              Family Floater
                            </label> */}
                          </div>
                        </div>
                      </div>

                      

                      <div className="row">
                        <div className="col-12 d-flex justify-content-center ">
                          <div className="row lesspadding">
                            <div className="col-sm-6 col-lg-auto d-flex flex-column mb-3">
                              <div className="btn-group">
                                <button
                                  key={1}
                                  className={
                                    active === "1"
                                      ? "p-0 btn mr-2  maleicon active"
                                      : "btn  maleicon p-0 mr-2"
                                  }
                                  id={"1"}
                                  onClick={handleClick}
                                >
                                  Male
                                </button>
                                <button
                                  key={2}
                                  className={
                                    active === "2"
                                      ? "p-0 btn  femaleicon active"
                                      : "btn  femaleicon p-0"
                                  }
                                  id={"2"}
                                  onClick={handleClick}
                                >
                                  Female
                                </button>
                              </div>
                            </div>

                            <div className="col-sm-6 col-lg-auto mb-3">
                              <input
                                type="text"
                                className="form-control sm-custom-wid"
                              />
                              <span className="text-danger"> Error* </span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="row">
                        <div className="col-12 d-flex justify-content-center align-items-center">
                          <div className="btn-group btngp mb-3 btngroup text-center">
                          <ButtonGroup
                            buttons={["Basic", "  Super Top-Up"]}
                            doSomethingAfterClick={printButtonLabel}
                              className="btn   mb-0"
                              ng-model="radioModel"
                              uib-btn-radio="'Left'"
                              uncheckable
                            >
                             
                            </ButtonGroup>
                            {/* <label
                              className="btn   mb-0"
                              ng-model="radioModel11"
                              uib-btn-radio="'Left'"
                              uncheckable
                            >
                              Basic
                            </label>
                            <label
                              className="btn   mb-0"
                              ng-model="radioModel11"
                              uib-btn-radio="'Middle'"
                              uncheckable
                            >
                              Super Top-Up
                            </label> */}
                          </div>
                        </div>
                      </div>

                      <div className="row d-flex align-items-center justify-content-center">
                        <div className="col-12 col-md-auto mb-3">
                          <select className="custom-select customwid">
                            <option selected="" value="Service">
                              Coverage Amount
                            </option>
                          </select>
                        </div>
                      </div>

                      <Link to="/Health/HealthFamilyDetail">
                        <div className="row">
                          <div className="col-12 text-center">
                            <button className="btn orangebtn mb-3 bigbutton">
                              {" "}
                              Get Quote{" "}
                            </button>
                          </div>
                        </div>
                      </Link>
                    </div>

                    <div className="card-footer text-center">
                      Already Have Quotation?{" "}
                      <a href="#" className="orangetext" ng-click="quotation()">
                        {" "}
                        Click here
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="container-fluid commoncl healthbg healthdiv d-flex align-items-center justify-content-center ">
        <div className="row flex-grow-1">
          <div className="col-12">
            <div className="container ">
              <div className="row">
                <div className="col-12 col-xl-10 offset-xl-1 ">
                  <div className="card commoncard">
                    <div className="card-header d-flex justify-content-center align-items-center">
                      <a href="#" className="backbutton">
                        <i className="fas fa-angle-double-left whtext"></i>{" "}
                        <span className="d-none d-md-inline-block">Back </span>
                      </a>
                      <h1>Health Insurance </h1>
                      <img
                        src="../img/logo-wh.png"
                        alt=" "
                        className="img-fluid whitelogo"
                      />
                    </div>
                    <div className="card-body" ng-show="ShowTab">
                      <div className="row">
                        <div className="col-12 d-flex justify-content-center align-items-center">
                          <div className="btn-group btngp mb-3">
                            <label
                              className="btn   mb-0"
                              ng-model="radioModel"
                              uib-btn-radio="'Left'"
                              uncheckable
                            >
                              Individual
                            </label>
                            <label
                              className="btn   mb-0"
                              ng-model="radioModel"
                              uib-btn-radio="'Middle'"
                              uncheckable
                            >
                              Family Floater
                            </label>
                          </div>
                        </div>
                      </div>

                      <div className="row">
                        <div className="col-12 d-flex justify-content-center ">
                          <div className="row lesspadding">
                            <div className="col-sm-6 col-lg-auto d-flex flex-column mb-3">
                              <div className="btn-group">
                                <button
                                  key={1}
                                  className={
                                    active === "1"
                                      ? "p-0 btn mr-2  maleicon active"
                                      : "btn  maleicon p-0 mr-2"
                                  }
                                  id={"1"}
                                  onClick={handleClick}
                                >
                                  Male
                                </button>
                                <button
                                  key={2}
                                  className={
                                    active === "2"
                                      ? "p-0 btn  femaleicon active"
                                      : "btn  femaleicon p-0"
                                  }
                                  id={"2"}
                                  onClick={handleClick}
                                >
                                  Female
                                </button>
                                {/* <label
                                  className="btn  maleicon mb-0 mr-2"
                                  ng-model="radioModel111"
                                  uib-btn-radio="'Left'"
                                  uncheckable
                                >
                                  Male
                                </label>
                                <label
                                  className="btn  femaleicon mb-0"
                                  ng-model="radioModel111"
                                  uib-btn-radio="'Middle'"
                                  uncheckable
                                >
                                  Female
                                </label> */}
                              </div>
                            </div>

                            <div className="col-sm-6 col-lg-auto mb-3">
                              <input
                                type="text"
                                className="form-control sm-custom-wid"
                              />
                              <span className="text-danger"> Error* </span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="row">
                        <div className="col-12 d-flex justify-content-center align-items-center">
                          <div className="btn-group btngp mb-3">
                            <label
                              className="btn   mb-0"
                              ng-model="radioModel11"
                              uib-btn-radio="'Left'"
                              uncheckable
                            >
                              Basic
                            </label>
                            <label
                              className="btn   mb-0"
                              ng-model="radioModel11"
                              uib-btn-radio="'Middle'"
                              uncheckable
                            >
                              Super Top-Up
                            </label>
                          </div>
                        </div>
                      </div>

                      <div className="row d-flex align-items-center justify-content-center">
                        <div className="col-12 col-md-auto mb-3">
                          <select className="custom-select customwid">
                            <option selected="" value="Service">
                              Deductible
                            </option>
                          </select>
                        </div>
                      </div>

                      <div className="row d-flex align-items-center justify-content-center">
                        <div className="col-12 col-md-auto mb-3">
                          <select className="custom-select customwid">
                            <option selected="" value="Service">
                              Coverage Amount
                            </option>
                          </select>
                        </div>
                      </div>

                      <Link to="/Health/HealthFamilyDetail">
                        <div className="row">
                          <div className="col-12 text-center">
                            <button className="btn orangebtn mb-3 bigbutton">
                              {" "}
                              Get Quote{" "}
                            </button>
                          </div>
                        </div>
                      </Link>
                    </div>

                    <div className="card-footer text-center">
                      Already Have Quotation?{" "}
                      <a href="#" className="orangetext" ng-click="quotation()">
                        {" "}
                        Click here
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default HealthInsurance;
