import React from "react";
import { Link } from "react-router-dom";
import { useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const HealthFamilyDetail = () => {
  const [selectedDate, setSelectedDate] = useState(null);
  return (
    <>
      <div class="container-fluid commoncl healthbg health-before-plan d-flex align-items-center justify-content-center">
        <div class="row flex-grow-1">
          <div class="col-12">
            <div class="container pl-0 pr-0 pl-lg-3 pr-lg-3">
              <div class="row">
                <div class="col-12 col-xl-10 offset-xl-1 familypage ">
                  <div class="card commoncard">
                    <div class="card-header d-flex justify-content-center align-items-center">
                      <a href="#" class="backbutton">
                        <i class="fas fa-angle-double-left whtext"></i>{" "}
                        <span class="d-none d-md-inline-block">Back </span>
                      </a>
                      <h1>Family Floater </h1>
                      <img
                        src="../img/logo-wh.png"
                        alt=" "
                        class="img-fluid whitelogo"
                      />
                    </div>
                    <div class="card-body" ng-show="ShowTab">
                      <div class="row">
                        <div class="col-12 col-xxl-10 offset-xxl-1">
                          <div class="row gridview">
                            <div class="col-12 col-md">
                              <div class="row lesspd">
                                <div class="col-auto">
                                  <label
                                    class="btn self-individual"
                                    ng-model="forself"
                                    ng-change="EnableDisable()"
                                    uib-btn-checkbox
                                  >
                                    <span> Self </span>
                                  </label>
                                </div>
                                <div class="col col-lg-auto">
                                  <fieldset
                                    ng-disabled="IsDisabled"
                                    class="mt-2 mt-lg-4"
                                  >
                                    {/*  <input
                                      type="date"
                                      name=""
                                      class="form-control floating-input"
                                      placeholder=" "
                                      uib-datepicker-popup="{{format}}"
                                      ng-model="dt"
                                      is-open="popup1.opened"
                                      datepicker-options="dateOptions"
                                      ng-required="true"
                                      close-text="Close"
                                      alt-input-formats="altInputFormats"
                                      required
                                      pattern="\d{2}-\d{2}-\d{4}"
                                    /> */}
                                    <DatePicker
                                      type="date" className="dateMonthYear"
                                      placeholderText={"DD-MM-YYYY"}
                                      selected={selectedDate}
                                      onChange={(date) => setSelectedDate(date)}
                                      dateFormat="dd/MM/yyyy"
                                      
                                      filterDate={(date) =>
                                        date.getDay() !== 6 &&
                                        date.getDay() !== 0
                                      }
                                      showYearDropdown
                                      scrollableYearDropdown 
                                      
                                     
                                    />
                                    
                                  </fieldset>
                                </div>
                              </div>
                            </div>
                            <div class="col-12 col-md">
                              <div class="row lesspd">
                                <div class="col-auto">
                                  <label
                                    class="btn father "
                                    ng-model="radioMode2"
                                    uib-btn-checkbox
                                  >
                                    <span> Father </span>{" "}
                                  </label>
                                </div>
                                <div class="col col-lg-auto">
                                  <fieldset ng-disabled="IsDisabled">
                                    <div class="input-group  dateinput flex-nowrap mt-2 mt-lg-4">
                                      {/* <input
                                        type="text"
                                        class="form-control floating-input"
                                        placeholder=" "
                                        uib-datepicker-popup="{{format}}"
                                        ng-model="dt"
                                        is-open="popup1.opened"
                                        datepicker-options="dateOptions"
                                        ng-required="true"
                                        close-text="Close"
                                        alt-input-formats="altInputFormats"
                                      /> */}
                                      <DatePicker
                                        type="date"
                                        selected={selectedDate}
                                        onChange={(date) =>
                                          setSelectedDate(date)
                                        }
                                        placeholderText={"dd/mm/yyyy"}
                                        dateFormat="dd/MM/yyyy"
                                        filterDate={(date) =>
                                          date.getDay() !== 6 &&
                                          date.getDay() !== 0
                                        }
                                        showYearDropdown
                                        scrollableYearDropdown
                                      />
                                
                                      <div class="input-group-append">
                                        {" "}
                                        <span
                                          class="input-group-text"
                                          ng-click="open1()"
                                        >
                                          <img src="img/dateicon.png" alt="" />
                                        </span>{" "}
                                      </div>
                                    </div>
                                  </fieldset>
                                </div>
                              </div>
                            </div>

                            <div class="col-12 col-md">
                              <div class="row lesspd">
                                <div class="col-auto">
                                  <label
                                    class="btn spouse "
                                    ng-model="radioMode4"
                                    uib-btn-checkbox
                                  >
                                    <span> Spouse </span>
                                  </label>
                                </div>
                                <div class="col col-lg-auto">
                                  <fieldset ng-disabled="IsDisabled">
                                    <div class="input-group  dateinput flex-nowrap mt-2 mt-lg-4">
                                      {/*   <input
                                        type="text"
                                        class="form-control floating-input"
                                        placeholder=" "
                                        uib-datepicker-popup="{{format}}"
                                        ng-model="dt"
                                        is-open="popup1.opened"
                                        datepicker-options="dateOptions"
                                        ng-required="true"
                                        close-text="Close"
                                        alt-input-formats="altInputFormats"
                                      /> */}
                                      <DatePicker
                                        type="date"
                                        selected={selectedDate}
                                        onChange={(date) =>
                                          setSelectedDate(date)
                                        }
                                        placeholderText={"dd/mm/yyyy"}
                                        dateFormat="dd/MM/yyyy"
                                        filterDate={(date) =>
                                          date.getDay() !== 6 &&
                                          date.getDay() !== 0
                                        }
                                        showYearDropdown
                                        scrollableYearDropdown
                                      />

                                      <div class="input-group-append">
                                        {" "}
                                        <span
                                          class="input-group-text"
                                          ng-click="open1()"
                                        >
                                          <img src="img/dateicon.png" alt="" />
                                        </span>{" "}
                                      </div>
                                    </div>
                                  </fieldset>
                                </div>
                              </div>
                            </div>

                            <div class="col-12 col-md">
                              <div class="row lesspd">
                                <div class="col-auto">
                                  <label
                                    class="btn mother "
                                    ng-model="radioMode5"
                                    uib-btn-checkbox
                                  >
                                    <span> Mother </span>
                                  </label>
                                </div>
                                <div class="col col-lg-auto">
                                  <fieldset ng-disabled="IsDisabled">
                                    <div class="input-group  dateinput flex-nowrap mt-2 mt-lg-4">
                                      {/*  <input
                                        type="text"
                                        class="form-control floating-input"
                                        placeholder=" "
                                        uib-datepicker-popup="{{format}}"
                                        ng-model="dt"
                                        is-open="popup1.opened"
                                        datepicker-options="dateOptions"
                                        ng-required="true"
                                        close-text="Close"
                                        alt-input-formats="altInputFormats"
                                      /> */}
                                      <DatePicker
                                        type="date"
                                        selected={selectedDate}
                                        onChange={(date) =>
                                          setSelectedDate(date)
                                        }
                                        placeholderText={"dd/mm/yyyy"}
                                        dateFormat="dd/MM/yyyy"
                                        filterDate={(date) =>
                                          date.getDay() !== 6 &&
                                          date.getDay() !== 0
                                        }
                                        showYearDropdown
                                        scrollableYearDropdown
                                      />
                                      <div class="input-group-append">
                                        {" "}
                                        <span
                                          class="input-group-text"
                                          ng-click="open1()"
                                        >
                                          <img src="img/dateicon.png" alt="" />
                                        </span>{" "}
                                      </div>
                                    </div>
                                  </fieldset>
                                </div>
                              </div>
                            </div>

                            <div class="col-12 col-md">
                              <div class="row lesspd">
                                <div class="col-auto">
                                  <label
                                    class="btn son "
                                    ng-model="radioMode6"
                                    uib-btn-checkbox
                                  >
                                    <span> Son </span>
                                  </label>
                                </div>
                                <div class="col col-lg-auto">
                                  <fieldset ng-disabled="IsDisabled">
                                    <div class="input-group  dateinput flex-nowrap mt-2 mt-lg-4">
                                      {/*  <input
                                        type="text"
                                        class="form-control floating-input"
                                        placeholder=" "
                                        uib-datepicker-popup="{{format}}"
                                        ng-model="dt"
                                        is-open="popup1.opened"
                                        datepicker-options="dateOptions"
                                        ng-required="true"
                                        close-text="Close"
                                        alt-input-formats="altInputFormats"
                                      /> */}
                                      <DatePicker
                                        type="date"
                                        selected={selectedDate}
                                        onChange={(date) =>
                                          setSelectedDate(date)
                                        }
                                        placeholderText={"dd/mm/yyyy"}
                                        dateFormat="dd/MM/yyyy"
                                        filterDate={(date) =>
                                          date.getDay() !== 6 &&
                                          date.getDay() !== 0
                                        }
                                        showYearDropdown
                                        scrollableYearDropdown
                                      />

                                      <div class="input-group-append">
                                        {" "}
                                        <span
                                          class="input-group-text"
                                          ng-click="open1()"
                                        >
                                          <img src="img/dateicon.png" alt="" />
                                        </span>{" "}
                                      </div>
                                    </div>
                                  </fieldset>
                                </div>

                                <div class="col-auto d-flex align-items-start mt-2 mt-lg-4">
                                  <div class="incrementdiv d-flex">
                                    <button
                                      class="rdbtn mr5"
                                      ng-click="decrement()"
                                    >
                                      -
                                    </button>
                                    <div class="valuecontainer">
                                      {" "}
                                      {/* {{counter}} */}
                                    </div>
                                    <button
                                      class="rdbtn ml5" /* ng-click="counter = counter + 1" */
                                    >
                                      +
                                    </button>
                                  </div>
                                </div>
                              </div>

                              <div class="row lesspd">
                                <div class="col-auto">
                                  <label
                                    class="btn son "
                                    ng-model="radioMode6"
                                    uib-btn-checkbox
                                  >
                                    <span> Son </span>
                                  </label>
                                </div>
                                <div class="col col-lg-auto">
                                  <fieldset ng-disabled="IsDisabled">
                                    <div class="input-group dateinput flex-nowrap mt-2 mt-lg-4">
                                      {/*   <input
                                        type="text"
                                        class="form-control floating-input"
                                        placeholder=" "
                                        ng-model="dt"
                                        is-open="popup1.opened"
                                        datepicker-options="dateOptions"
                                        ng-required="true"
                                        close-text="Close"
                                        alt-input-formats="altInputFormats"
                                      /> */}
                                      <DatePicker
                                        type="date"
                                        selected={selectedDate}
                                        onChange={(date) =>
                                          setSelectedDate(date)
                                        }
                                        placeholderText={"dd/mm/yyyy"}
                                        dateFormat="dd/MM/yyyy"
                                        filterDate={(date) =>
                                          date.getDay() !== 6 &&
                                          date.getDay() !== 0
                                        }
                                        showYearDropdown
                                        scrollableYearDropdown
                                      />

                                      <div class="input-group-append">
                                        {" "}
                                        <span
                                          class="input-group-text"
                                          ng-click="open1()"
                                        >
                                          <img src="img/dateicon.png" alt="" />
                                        </span>{" "}
                                      </div>
                                    </div>
                                  </fieldset>
                                </div>
                              </div>
                            </div>

                            <div class="col-12 col-md">
                              <div class="row lesspd">
                                <div class="col-auto">
                                  <label
                                    class="btn daughter"
                                    ng-model="radioMode7"
                                    uib-btn-checkbox
                                  >
                                    <span> Daughter </span>
                                  </label>
                                </div>
                                <div class="col col-lg-auto">
                                  <fieldset ng-disabled="IsDisabled">
                                    <div class="input-group  dateinput flex-nowrap mt-2 mt-lg-4">
                                      {/*  <input
                                        type="text"
                                        class="form-control floating-input"
                                        placeholder=" "
                                        uib-datepicker-popup="{{format}}"
                                        ng-model="dt"
                                        is-open="popup1.opened"
                                        datepicker-options="dateOptions"
                                        ng-required="true"
                                        close-text="Close"
                                        alt-input-formats="altInputFormats"
                                      />  */}
                                      <DatePicker
                                        type="date"
                                        selected={selectedDate}
                                        onChange={(date) =>
                                          setSelectedDate(date)
                                        }
                                        placeholderText={"dd/mm/yyyy"}
                                        dateFormat="dd/MM/yyyy"
                                        filterDate={(date) =>
                                          date.getDay() !== 6 &&
                                          date.getDay() !== 0
                                        }
                                        showYearDropdown
                                        scrollableYearDropdown
                                      />

                                      <div class="input-group-append">
                                        {" "}
                                        <span
                                          class="input-group-text"
                                          ng-click="open1()"
                                        >
                                          <img src="img/dateicon.png" alt="" />
                                        </span>{" "}
                                      </div>
                                    </div>
                                  </fieldset>
                                </div>

                                <div class="col-auto d-flex align-items-start mt-2 mt-lg-4">
                                  <div class="incrementdiv d-flex">
                                    <button
                                      class="rdbtn mr5"
                                      ng-click="decrement()"
                                    >
                                      -
                                    </button>
                                    <div class="valuecontainer">
                                      {" "}
                                      {/* {{counter}} */}
                                    </div>
                                    <button
                                      class="rdbtn ml5" /* ng-click="counter = counter + 1" */
                                    >
                                      +
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div class="row mt-lg-3">
                            <div class="col-md-6">
                              <div class="form-group row">
                                <label class="col-md-auto mt-2">
                                  Disease Suffered
                                </label>
                                <div class="col-md-auto">
                                  <div class="btn-group mb-3">
                                    <label
                                      class="btn generalbtn"
                                      ng-model="radioModel"
                                      uib-btn-radio="'Yes'"
                                      uncheckable
                                    >
                                      Yes
                                    </label>
                                    <label
                                      class="btn generalbtn"
                                      ng-model="radioModel"
                                      uib-btn-radio="'No'"
                                      uncheckable
                                    >
                                      No
                                    </label>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div class="col-md-6">
                              <div class="form-group row">
                                <label class="col-md-auto mt-2">
                                  Tenure Year
                                </label>
                                <div class="col-md-auto">
                                  <div class="btn-group mb-3">
                                    <label
                                      class="btn generalbtn"
                                      ng-model="radioModelaa"
                                      uib-btn-radio="'Yes'"
                                      uncheckable
                                    >
                                      1
                                    </label>
                                    <label
                                      class="btn generalbtn"
                                      ng-model="radioModelaa"
                                      uib-btn-radio="'No'"
                                      uncheckable
                                    >
                                      2
                                    </label>

                                    <label
                                      class="btn generalbtn"
                                      ng-model="radioModelaa"
                                      uib-btn-radio="'No'"
                                      uncheckable
                                    >
                                      3
                                    </label>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <Link to="/Health/HealthReviewPay">
                      <div class="text-center pb-3">
                        <a href="#" class="orangebtn d-inline-block">
                          GET QUOTES
                        </a>
                      </div>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="container-fluid commoncl healthbg health-before-plan d-flex align-items-center justify-content-center">
        <div className="row flex-grow-1">
          <div className="col-12">
            <div className="container">
              <div className="row">
                <div className="col-12 col-xl-10 offset-xl-1 ">
                  <div className="card commoncard">
                    <div className="card-header d-flex justify-content-center align-items-center">
                      <a href="#" className="backbutton">
                        <i className="fas fa-angle-double-left whtext"></i>{" "}
                        <span className="d-none d-md-inline-block">Back </span>
                      </a>
                      <h1>Individual </h1>
                      <img
                        src="../img/logo-wh.png"
                        alt=" "
                        className="img-fluid whitelogo"
                      />
                    </div>
                    <div className="card-body" ng-show="ShowTab">
                      <div className="row">
                        <div className="col-xl-10 offset-xl-1">
                          <div className="row">
                            <label className="col-12 col-xl-3 mt-3">
                              Insured Member Type
                            </label>
                            <div className="col-12 col-xl-9 ">
                              <div className="btn-group individualbtn  mb-3">
                                <label
                                  className="btn self-individual"
                                  ng-model="radioModel"
                                  uib-btn-radio="'Self'"
                                  uncheckable
                                >
                                  <span> Self </span>
                                </label>
                                <label
                                  className="btn spouse"
                                  ng-model="radioModel"
                                  uib-btn-radio="'Spouse'"
                                  uncheckable
                                >
                                  <span> Spouse </span>
                                </label>
                                <label
                                  className="btn father"
                                  ng-model="radioModel"
                                  uib-btn-radio="'Father'"
                                  uncheckable
                                >
                                  <span> Father</span>
                                </label>
                                <label
                                  className="btn mother"
                                  ng-model="radioModel"
                                  uib-btn-radio="'Mother'"
                                  uncheckable
                                >
                                  <span> Mother</span>
                                </label>
                                <label
                                  className="btn son"
                                  ng-model="radioModel"
                                  uib-btn-radio="'Son'"
                                  uncheckable
                                >
                                  <span> Son </span>
                                </label>
                                <label
                                  className="btn daughter"
                                  ng-model="radioModel"
                                  uib-btn-radio="'Daughter'"
                                  uncheckable
                                >
                                  <span> daughter </span>
                                </label>
                              </div>
                            </div>
                          </div>

                          <div className="row">
                            <label className="col-12 col-xl-3 mt-2">
                              Insured Age
                            </label>

                            <div className="col-12 col-xl-9 mb-3">
                              <select className="custom-select forselbox">
                                <option selected="" value="Select">
                                  Select
                                </option>
                              </select>
                            </div>
                          </div>

                          <div className="row">
                            <label className="col-12 col-xl-3 mt-2">
                              Deductable
                            </label>

                            <div className="col-12 col-xl-9 mb-3">
                              <select className="custom-select forselbox">
                                <option selected="" value="Select">
                                  Select
                                </option>
                              </select>
                            </div>
                          </div>

                          <div className="row">
                            <label className="col-md-3 mt-2">
                              Disease Suffered
                            </label>

                            <div className="col-md-9">
                              <div className="btn-group mb-3">
                                <label
                                  className="btn generalbtn"
                                  ng-model="radioModel"
                                  uib-btn-radio="'Yes'"
                                  uncheckable
                                >
                                  {" "}
                                  Yes
                                </label>
                                <label
                                  className="btn generalbtn"
                                  ng-model="radioModel"
                                  uib-btn-radio="'No'"
                                  uncheckable
                                >
                                  No
                                </label>
                              </div>

                              <a href="#" ng-click="deceasepop()">
                                popup{" "}
                              </a>
                            </div>
                          </div>

                          <div className="row">
                            <label className="col-md-3 mt-2">Tenure Year</label>

                            <div className="col-md-9">
                              <div className="btn-group mb-3">
                                <label
                                  className="btn generalbtn"
                                  ng-model="radioModel"
                                  uib-btn-radio="'one'"
                                  uncheckable
                                >
                                  {" "}
                                  1
                                </label>
                                <label
                                  className="btn generalbtn"
                                  ng-model="radioModel"
                                  uib-btn-radio="'two'"
                                  uncheckable
                                >
                                  2
                                </label>
                                <label
                                  className="btn generalbtn"
                                  ng-model="radioModel"
                                  uib-btn-radio="'three'"
                                  uncheckable
                                >
                                  3
                                </label>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <Link to="/Health/HealthReviewPay">
                        <div className="text-center pb-3">
                          <a href="#" className="orangebtn d-inline-block">
                            GET QUOTES
                          </a>
                        </div>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default HealthFamilyDetail;
