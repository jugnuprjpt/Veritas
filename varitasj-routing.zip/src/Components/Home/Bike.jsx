import React from 'react'

const Bike = () => {
  return (
    <>
     
    </>
  )
}

export default Bike
