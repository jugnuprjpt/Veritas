import React from "react";
import { Link } from "react-router-dom";

/* import "./Home.css" */
const Home = () => {
  return (
    <>
      <div className="veritasmain_uldiv">
        <div className="section1_backgrounddiv">
          <div className="section1_all_keyhightlight">
            <ul
              className="section1_all_keyhightlightul"
              style={{
                display: "flex",
                justifyContent: "space-evenly",
                marginTop: "250px",
              }}
            >
              <Link to="/Private">
                <li>
                  <div className="keyhightlightblock block1">
                    <div className="keyhightlightimg_block">
                      <img
                        src="img/dashboard-car.png"
                        alt="veritas"
                        className="img-responsive"
                      />
                    </div>
                    <div className="keyhightlighttext">
                      <p className=" font-14 color_black "> Private car </p>
                    </div>
                  </div>
                </li>
              </Link>
              <Link to="/Health">
                <li>
                  <div className="keyhightlightblock block2">
                    <div className="keyhightlightimg_block">
                      <img
                        src="img/dashboard-health.png"
                        alt="veritas"
                        className="img-responsive"
                      />
                    </div>

                    <div className="keyhightlighttext">
                      <p className=" font-14 color_black ">Health </p>
                    </div>
                  </div>
                </li>
              </Link>
              <Link to="/Bike">
                <li>
                  <div className="keyhightlightblock block3">
                    <div className="keyhightlightimg_block">
                      <img
                        src="img/dashboard-bike.png"
                        alt="veritas"
                        className="img-responsive"
                      />
                    </div>
                    <div className="keyhightlighttext">
                      <p className=" font-14 color_black ">Bike</p>
                    </div>
                  </div>
                </li>
              </Link>
              <Link to="/Commercial">
                <li>
                  <div className="keyhightlightblock block4">
                    <div className="keyhightlightimg_block">
                      <img
                        src="img/commercial-review-pay.png"
                        alt="veritas"
                        className="img-responsive"
                        style={{ width: "150px", height: "75px" }}
                      />
                    </div>
                    <div className="keyhightlighttext">
                      <p className=" font-14 color_black ">Commercial</p>
                    </div>
                  </div>
                </li>
              </Link>
              <Link to="/Travel">
                <li>
                  <div className="keyhightlightblock block3">
                    <div className="keyhightlightimg_block">
                      <img
                        src="img/plane.png"
                        alt="veritas"
                        className="img-responsive"
                        style={{ width: "150px", height: "75px" }}
                      />
                    </div>
                    <div className="keyhightlighttext">
                      <p className=" font-14 color_black ">Travel</p>
                    </div>
                  </div>
                </li>
              </Link>
            </ul>
            <div className="clearfix"></div>
          </div>
          <div className="clearfix"></div>
        </div>
      </div>
    </>
  );
};

export default Home;
