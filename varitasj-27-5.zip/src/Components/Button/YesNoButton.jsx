import React from 'react'



const YesNoButton = ({ buttons, doSomethingAfterClick }) => {
    const [clickedId, setClickedId] = useState(-1);
  
    const handleClick = (event, id) => {
      setClickedId(id);
      doSomethingAfterClick(event);
      console.log(buttons.i);
    };
  
    return (
      <>
        {buttons.map((buttonLabel, i) => (
          <button
            key={i}
            name={buttonLabel}
            onClick={(event) => handleClick(event, i)}
            className={i === clickedId ? "btn active" : "btn"}
          >
            {buttonLabel}
          </button>
         
        ))}
  
  
      </>
    );
  };

export default YesNoButton