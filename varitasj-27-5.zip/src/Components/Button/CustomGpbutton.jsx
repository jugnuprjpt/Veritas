import React, { useState } from "react";

const CustomGpbutton = ( ) => {

    const [active, setActive] = useState("");
 
    const handleClick = (event) => {
      setActive(event.target.id);
      
    }
    
    return (
        <>
           
           <div className="btn-group">

           <button
        key={1}
        className={active === "1" ? "p-0 btn mr-2  maleicon active" : "btn  maleicon p-0 mr-2"}
        id={"1"}
        onClick={handleClick}
      >
        Male
      </button>

       <button
       key={2}
       className={active === "2" ? "p-0 btn  femaleicon active" : "btn  femaleicon p-0"}
       id={"2"}
       onClick={handleClick}
     >
    Female
     </button>

      

</div>
      

        
   
            
        </>
    );
};

export default CustomGpbutton;