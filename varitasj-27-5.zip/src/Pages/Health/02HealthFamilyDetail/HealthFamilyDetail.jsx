import React from "react";
import { useState } from "react";
import { Link } from "react-router-dom";
import "react-datepicker/dist/react-datepicker.css";
import Map from "../../../Components/Button/multiselectbutton";
import Individualbtn from "../../../Components/Button/Individualbtns";
import DatePickerFamily from "../../../Components/DatePickerFamily/DatePickerFamily";
import ButtonGroup from "../../../Components/Button/ButtonGroup";
import CustomGpbutton from "../../../Components/Button/CustomGpbutton";

const HealthFamilyDetail = () => {
  const [active, setActive] = useState("");

  const handleClick = (event) => {
    setActive(event.target.id);
  };

  const printButtonLabel = (event) => {
    console.log(event.target.name);
  };
  return (
    <>
      <div class="container-fluid commoncl healthbg health-before-plan d-flex align-items-center justify-content-center">
        <div class="row flex-grow-1">
          <div class="col-12">
            <div class="container pl-0 pr-0 pl-lg-3 pr-lg-3">
              <div class="row">
                <div class="col-12 col-xl-10 offset-xl-1 familypage ">
                  <div class="card commoncard">
                    <div class="card-header d-flex justify-content-center align-items-center">
                      <a href="#" class="backbutton">
                        <i class="fas fa-angle-double-left whtext"></i>{" "}
                        <span class="d-none d-md-inline-block">Back </span>
                      </a>
                      <h1>Family Floater </h1>
                      <img
                        src="../img/logo-wh.png"
                        alt=" "
                        class="img-fluid whitelogo"
                      />
                    </div>
                    <div class="card-body" ng-show="ShowTab">
                      <div class="row">
                        <div class="col-12 col-xxl-10 offset-xxl-1">
                          <Map></Map>

                          <div class="row mt-lg-3">
                            <div class="col-md-6">
                              <div class="form-group row btn-group btngp mb-3 btngroup text-center">
                                <label class="col-md-auto mt-2">
                                  Disease Suffered
                                </label>
                                <div className="btngroup general-btn ">
                                  <ButtonGroup
                                    buttons={["Yes", "No"]}
                                    doSomethingAfterClick={printButtonLabel}
                                  />
                                </div>

                                <div class="col-md-auto">
                                  <div class="btn-group mb-3">
                                   
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div class="col-md-6">
                              <div class="form-group row">
                                <label class="col-md-3 mt-2">Tenure Year</label>
                                <div className="col-md-5">
                                  <div className="btngroup text-center general-btn ">
                                    <ButtonGroup
                                      buttons={["1", "2", "3"]}
                                      doSomethingAfterClick={printButtonLabel}
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <Link to="/Health/HealthReviewPay">
                        <div class="text-center pb-3">
                          <a href="#" class="orangebtn d-inline-block">
                            GET QUOTES
                          </a>
                        </div>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ---------------individual------------------ */}

      <div className="container-fluid commoncl healthbg health-before-plan d-flex align-items-center justify-content-center">
        <div className="row flex-grow-1">
          <div className="col-12">
            <div className="container">
              <div className="row">
                <div className="col-12 col-xl-10 offset-xl-1 ">
                  <div className="card commoncard">
                    <div className="card-header d-flex justify-content-center align-items-center">
                      <a href="#" className="backbutton">
                        <i className="fas fa-angle-double-left whtext"></i>{" "}
                        <span className="d-none d-md-inline-block">Back </span>
                      </a>
                      <h1>Individual </h1>
                      <img
                        src="../img/logo-wh.png"
                        alt=" "
                        className="img-fluid whitelogo"
                      />
                    </div>
                    <div className="card-body" ng-show="ShowTab">
                      <div className="row">
                        <div className="col-xl-10 offset-xl-1">
                          <div className="row">
                            <label className="col-12 col-xl-3 mt-3">
                              Insured Member Type
                            </label>

                            <div className="col-12 col-xl-9 ">
                              <div className="btn-group individualbtn  mb-3 ">
                                <Individualbtn></Individualbtn>
                              </div>
                            </div>
                          </div>

                          <div className="row">
                            <label className="col-12 col-xl-3 mt-4">
                              Insured Date Of Birth
                            </label>

                            <div className="col-12 col-xl-5 mb-3 ">
                              <DatePickerFamily></DatePickerFamily>
                            </div>
                          </div>

                          <div className="row ">
                            <label className="col-md-3 mt-2 ">
                              Disease Suffered
                            </label>

                            <div className="col-md-9">
                              <div className="btngroup general-btn ">
                                <ButtonGroup
                                  buttons={["Yes", "No"]}
                                  doSomethingAfterClick={printButtonLabel}
                                />
                                &nbsp;
                                <a href="#" ng-click="deceasepop()">
                                <p  data-toggle="modal" data-target="#exampleModalCenter">
  Pop up
</p>


<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Health Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      
   
    
    <div class="modal-body" id="modal-body">
  
        <div class="table-responsive">
                    <table class="table table-bordered table-condensed text-center">
                      <thead>
                        <tr>
                          <th>Member</th>
                          <th>Asthma</th>
                          <th>Diabetes</th>
                          <th>Heart Ailments</th>
                          <th>Hypertension</th>
                          <th>Thyroid</th>
                        </tr>
                      </thead>
                      <tbody>
                        
                        <tr>
                          <td class="ng-binding">
                            Spouse
                          </td>
                          <td>
                           

                            <div class="custom-control custom-checkbox ">
                              <input type="checkbox" class="custom-control-input" id="customCheck1" ng-model="ShowPassport1"/>
                              <label class="custom-control-label" for="customCheck1"></label>
                            </div>

                          </td>
                          <td>
                            <div class="custom-control custom-checkbox ">
                              <input type="checkbox" class="custom-control-input" id="customCheck1" ng-model="ShowPassport1"/>
                              <label class="custom-control-label" for="customCheck1"></label>
                            </div>
                          </td>
                          <td>
                            <div class="custom-control custom-checkbox ">
                              <input type="checkbox" class="custom-control-input" id="customCheck1" ng-model="ShowPassport1"/>
                              <label class="custom-control-label" for="customCheck1"></label>
                            </div>
                          </td>
                          <td>
                            <div class="custom-control custom-checkbox ">
                              <input type="checkbox" class="custom-control-input" id="customCheck1" ng-model="ShowPassport1"/>
                              <label class="custom-control-label" for="customCheck1"></label>
                            </div>
                          </td>
                          <td>
                            <div class="custom-control custom-checkbox ">
                              <input type="checkbox" class="custom-control-input" id="customCheck1" ng-model="ShowPassport1"/>
                              <label class="custom-control-label" for="customCheck1"></label>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td class="ng-binding">
                            Daughter
                          </td>
                          <td>
                            <div class="custom-control custom-checkbox ">
                              <input type="checkbox" class="custom-control-input" id="customCheck1" ng-model="ShowPassport1"/>
                              <label class="custom-control-label" for="customCheck1"></label>
                            </div>
                          </td>
                          <td>
                            <div class="custom-control custom-checkbox ">
                              <input type="checkbox" class="custom-control-input" id="customCheck1" ng-model="ShowPassport1"/>
                              <label class="custom-control-label" for="customCheck1"></label>
                            </div>
                          </td>
                          <td>
                            <div class="custom-control custom-checkbox ">
                              <input type="checkbox" class="custom-control-input" id="customCheck1" ng-model="ShowPassport1"/>
                              <label class="custom-control-label" for="customCheck1"></label>
                            </div>
                          </td>
                          <td>
                            <div class="custom-control custom-checkbox ">
                              <input type="checkbox" class="custom-control-input" id="customCheck1" ng-model="ShowPassport1"/>
                              <label class="custom-control-label" for="customCheck1"></label>
                            </div>
                          </td>
                          <td>
                            <div class="custom-control custom-checkbox ">
                              <input type="checkbox" class="custom-control-input" id="customCheck1" ng-model="ShowPassport1"/>
                              <label class="custom-control-label" for="customCheck1"></label>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            Son
                          </td>
                          <td>
                            <div class="custom-control custom-checkbox ">
                              <input type="checkbox" class="custom-control-input" id="customCheck1" ng-model="ShowPassport1"/>
                              <label class="custom-control-label" for="customCheck1"></label>
                            </div>
                          </td>
                          <td>
                            <div class="custom-control custom-checkbox ">
                              <input type="checkbox" class="custom-control-input" id="customCheck1" ng-model="ShowPassport1"/>
                              <label class="custom-control-label" for="customCheck1"></label>
                            </div>
                          </td>
                          <td>
                            <div class="custom-control custom-checkbox ">
                              <input type="checkbox" class="custom-control-input" id="customCheck1" ng-model="ShowPassport1"/>
                              <label class="custom-control-label" for="customCheck1"></label>
                            </div>
                          </td>
                          <td>
                            <div class="custom-control custom-checkbox ">
                              <input type="checkbox" class="custom-control-input" id="customCheck1" ng-model="ShowPassport1"/>
                              <label class="custom-control-label" for="customCheck1"></label>
                            </div>
                          </td>
                          <td>
                            <div class="custom-control custom-checkbox ">
                              <input type="checkbox" class="custom-control-input" id="customCheck1" ng-model="ShowPassport1"/>
                              <label class="custom-control-label" for="customCheck1"></label>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
  
    </div>
    <div class="modal-footer">
        <button class="orangebtn border-0 pl25 pr25 mt-3" type="button" ng-click="ok()">Update Quotes</button>
    </div>
  
      </div>
     
    </div>
  </div>
</div>
                                </a>
                                
                              </div>
                            </div>
                          </div>

                          <div className="row mt-3">
                            <label className="col-md-3 mt-3">Tenure Year</label>

                            <div className="col-md-3 mt-2">
                              <div className="btngroup text-center general-btn ">
                                <ButtonGroup
                                  buttons={["1", "2", "3"]}
                                  doSomethingAfterClick={printButtonLabel}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <Link to="/Health/HealthReviewPay">
                        <div className="text-center pb-3 mt-4">
                          <a href="#" className="orangebtn d-inline-block">
                            GET QUOTES
                          </a>
                        </div>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default HealthFamilyDetail;
