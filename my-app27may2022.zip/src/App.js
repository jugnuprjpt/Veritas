import './App.css';
import ButtonGroup from './ButtonGroup';
import CustomGpbutton from './CustomGpbutton';
import Map from './multiselectbutton';
import Individualbtn  from './Individualbtns';
import Example from './datepicker';


import Header  from './Header';
import Footer  from './Footer';

function App() {
  const printButtonLabel = (event) => {
    console.log(event.target.name);
    //do some stuff here
  };
  return (    
    <>
    <Header></Header>
    <div className='btngroup text-center customButton'>
    <ButtonGroup
        buttons={["One", "Two"]}
        doSomethingAfterClick={printButtonLabel}
      />
      </div>

      <div className='btngroup text-center general-btn '>
    <ButtonGroup
        buttons={["Yes", "No"]}
        doSomethingAfterClick={printButtonLabel}
      />
      </div>

      <div className='btngroup text-center general-btn '>
    <ButtonGroup
        buttons={["1", "2", "3"]}
        doSomethingAfterClick={printButtonLabel}
      />
      </div>

      

      <CustomGpbutton></CustomGpbutton>
      <Map></Map>
      <Individualbtn></Individualbtn>
<Example></Example>
    <Footer></Footer>
    
    </>
  );
}

export default App;
