import React, { useState } from "react";
import DatePicker from "react-datepicker";

import "react-datepicker/dist/react-datepicker.css";

import "react-datepicker/dist/react-datepicker.css";

// CSS Modules, react-datepicker-cssmodules.css
// import 'react-datepicker/dist/react-datepicker-cssmodules.css';

const Example = () => {
    
        const [startDate, setStartDate] = useState(new Date());

        
       const forwardRef = React.forwardRef
        const ExampleCustomInput = forwardRef(({ value, onClick }, ref) => (
            <>
          <div class="input-group  dateinput flex-nowrap mt-2 mt-lg-4">


          <input    type="text" class="form-control floating-input"  ref={ref} 
          value={value}
            />
          <div class="input-group-append" onClick={onClick} > <span class="input-group-text"
              ><img src="img/dateicon.png" alt="" /></span> </div>
        </div>

          
          </>
          
        ));
        return (
          <DatePicker
            selected={startDate}
            onChange={(date) => setStartDate(date)}
            customInput={<ExampleCustomInput />}
          />
        );
      };

export default Example;