import React, { useState } from "react";

const Individualbtn = ( ) => {

    const [active, setActive] = useState("");
 
    const handleClick = (event) => {
      setActive(event.target.id);
      
    }
    

    return (
        <>
           <div className="health-before-plan">
           <div className="individualbtn" >

           <button
        key={1}
        className={active === "1" ? "btn self-individual active" : "btn self-individual"}
        id={"1"}
        onClick={handleClick}
      >
        Self
      </button>

       <button
       key={2}
       className={active === "2" ? "btn spouse active" : "btn spouse"}
       id={"2"}
       onClick={handleClick}
     >
    Spouse
     </button>

     <button
       key={3}
       className={active === "3" ? "btn father active" : "btn father"}
       id={"3"}
       onClick={handleClick}
     >
    Father
     </button>

     
     <button
       key={4}
       className={active === "4" ? "btn mother active" : "btn mother"}
       id={"4"}
       onClick={handleClick}
     >
    Mother
     </button>

   
     <button
       key={5}
       className={active === "5" ? "btn son active" : "btn son"}
       id={"5"}
       onClick={handleClick}
     >
    Son
     </button>

     <button
       key={6}
       className={active === "6" ? "btn daughter active" : "btn daughter"}
       id={"6"}
       onClick={handleClick}
     >
    Daughter
     </button>
      

</div>
      

</div>
   
            
        </>
    );
};

export default Individualbtn;