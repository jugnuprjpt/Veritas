import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./Home/Home";
import Header from "./Header/Header";
import Login from "./Header/Login.jsx";
import Health from "./Home/Health";
import Footer from "./Footer/Footer";
import HealthInsurance from "../Pages/Health/01HealthInsurance/HealthInsurance";
import HealthFamilyDetail from "../Pages/Health/02HealthFamilyDetail/HealthFamilyDetail";
import HealthReviewPay from "../Pages/Health/03HealthReviewPay/HealthReviewPay";
import HealthProposal from "../Pages/Health/04HealthProposal/HealthProposal.jsx"; 
import HealthRaviewPay from "../Pages/Health/05HealthRaviewPay/HealthRaviewPay.jsx"; 
import HealthPayment from "../Pages/Health/06HealthPayment/HealthPayment.jsx"; 
import HealthPaymentSucess from "../Pages/Health/07HealthPaymentSucess/HealthPaymentSucess.jsx"; 
import Main from "./Main/Main";


function MyAppRouting() {
  return (
    <>
      <BrowserRouter>
        <Header></Header>
        
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="Login" element={<Login />}>
          </Route>
          <Route path="Health" element={<Health />}>
          </Route>
              <Route path="HealthInsurance" element={<HealthInsurance />}/>  
              <Route path="HealthFamilyDetail" element={<HealthFamilyDetail />}/>  
              <Route path="HealthReviewPay" element={<HealthReviewPay />}/>
              <Route path="HealthProposal" element={<HealthProposal />}/>
              <Route path="HealthRaviewPay" element={<HealthRaviewPay />}/>
              <Route path="HealthPayment" element={<HealthPayment />}/>
              <Route path="HealthPaymentSucess" element={<HealthPaymentSucess />}/>
              
      
          
        </Routes>
        
      <Footer></Footer>
      </BrowserRouter>
    </>
  );
}

export default MyAppRouting;
