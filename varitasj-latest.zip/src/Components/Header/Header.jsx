import React from "react";
import { Link } from "react-router-dom";

const Header = () => {
  return (
    <>
      <nav className="navbar navbar-expand-md flex-wrap menu fixed-top innerpagemenu">
        <div className="row flex-grow-1">
          <div className="col-12">
            <div className="row">
              <div className="col-12 col-md-auto d-flex">
                <a className="navbar-brand order-md-1" href="#">
                  <img src="../img/logo.png" alt="" />
                </a>
                <button
                  className="navbar-toggler ml-auto"
                  type="button"
                  data-toggle="collapse"
                  data-target="#navbarsExampleDefault"
                  aria-controls="navbarsExampleDefault"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <i className="fas fa-bars"></i>
                </button>
              </div>
              <div className="col-12 col-md flex-grow-1 d-flex align-items-center flex-column">
                <div className="d-flex flex-grow-1 w-100 flex-wrap ">
                  <div
                    className="collapse navbar-collapse  justify-content-center order-2 order-md-0"
                    id="navbarsExampleDefault"
                  >
                    <ul className="navbar-nav d-md-flex flex-md-wrap ">
                      <li className="nav-item">
                        <Link
                          to="/AboutUs"
                          className="nav-link"
                          title="Our Partners &amp; Services"
                        >
                          About Us
                        </Link>
                      </li>
                      <li className="nav-item">
                        <Link
                          to="/User Guide"
                          className="nav-link"
                          title="User Guide"
                        >
                          User Guide
                        </Link>
                      </li>
                      <li className="nav-item">
                        <Link
                          to="/Support"
                          className="nav-link"
                          title="Support"
                        >
                          Support
                        </Link>
                      </li>
                      <li className="nav-item">
                        <Link
                          to="/GetPolicyPDF"
                          className="nav-link"
                          title=" Get PolicyPDF "
                        >
                          Get PolicyPDF
                        </Link>
                      </li>
                      <li className="nav-item">
                        <Link
                          to="/InspectionStatus"
                          className="nav-link"
                          title="Inspection Status"
                        >
                          Inspection Status
                        </Link>
                      </li>
                    </ul>
                  </div>
                  <div className="order-0 order-md-1 ml-md-auto">
                    <a
                      href="#"
                      className="orangebtn  text-nowrap mr-2 d-inline-block"
                    >
                      <img src="img/Login_Icon_1.png" alt="" />
                      Join As PoSP
                    </a>
                    <Link to = "/Login">
                    <a
                      href="#"
                      className="orangebtn text-nowrap d-inline-block"
                    >
                      <img src="img/Login_Icon_1.png" alt="" />
                      Login
                    </a>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </nav>
    </>
  );
};

export default Header;
