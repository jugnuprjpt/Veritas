import React from 'react'
import { Link } from 'react-router-dom'

const HealthPayment = () => {
  return (
    <>
      <Link to = "/HealthPaymentSucess">
        <div className="contianer" style={{marginTop:"100px"}}>
            <div className="row">
                <div className="col">
                    <img src="img/comp-logo/adityabirla.png" alt="aditya" />
                    <button>NEXT PAGE JUMP HERE JUST DEMO</button>
                </div>
            </div>
        </div>
        </Link>
    </>
  )
}

export default HealthPayment