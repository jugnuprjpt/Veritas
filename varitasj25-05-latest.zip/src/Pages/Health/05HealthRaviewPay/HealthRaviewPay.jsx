import React from 'react'
import { Link } from 'react-router-dom'

const HealthRaviewPay = () => {
  return (
    <>
<div class="container-fluid commoncl" >

<div class="row">
  <div class="col-12 health-reviewpage-bg pt-md-3 pb-md-3">

    <div class="container">
      <div class="row">
        <div class="col-md-6 col-xxl-8 whbg pt-md-3 pb-md-3 pl-xl-5 pr-xl-5 posch">
          <div class="row justify-content-between align-items-center">
            <div class="col">
              <img src="img/comp-logo/adityabirla.png" alt="" class="img-fluid mb-3" />
            </div>
            <div class="col text-right">

              <div class="d-flex flex-column premiumamount">
                <span class="orangetext"> Premium </span>
                <span class="orangetext font-weight-semi-bold">
                  <i class="fas fa-rupee-sign mr-1"></i> 25000
                </span>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-12 ">
              <p><strong> Policy Start Date : </strong> 12-Feb-2019</p>
              <p><strong> Policy End Date : </strong> 03-Feb-2021</p>
              <hr class="horizantalline" />
              <p><strong> Quotation Number : </strong> VTSBMTRPC2019070917335816</p>
              <p>
                <strong> Vehicle Model : </strong> MARUTI SWIFT DZIRE LXI (1298 cc) - PETROL
              </p>

            </div>
          </div>
        </div>
      </div>

    </div>

  </div>
</div>



<div class="container mt-5 mb-5">

  <div class="row">
    <div class="col-12"><a href="#" class="orangetext" ><i class="fas fa-angle-double-left "></i> Back</a></div>
  </div>  

  <div class="health-review-pay shadow p-3 pl-md-4 pr-md-4 pl-xl-5 pr-xl-5 ">

    <div class="row">
      <div class="col-12 d-flex  justify-content-center">
        <h2 class="orangetext mb-3 mt-2">Review & Pay (Private Car)</h2>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <h3 class="orangetext">Policy Holder Details</h3>
        <div class="bdr p-3 mb-3  ">
          <div class="row">
            <div class="col-12 col-md-4 col-lg-3">
              <p class="mb-1"><strong>Name</strong></p>
              <p>Mr. Jigar Pankajbhai Barot</p>
            </div>
            <div class="col-12 col-md-4 col-lg-3 col-xl-2">
              <p class="mb-1"><strong>Birthdate</strong></p>
              <p>05-Jun-1988</p>
            </div>
            <div class="col-12 col-md-4 col-lg-3 col-xl-3">
              <p class="mb-1"><strong>Email Address</strong></p>
              <p><a href="mailto:test@gmail.com orangetext" class="orangetext">test@gmail.com</a></p>
            </div>
            <div class="col-12 col-md-4 col-lg-3 col-xl-4">
              <p class="mb-1"><strong>Communication Address</strong></p>
              <p>E-101, Ariane Casa, Adalaj, GUJARAT-382421</p>
            </div>
            <div class="col-12 col-md-4 col-lg-3">
              <p class="mb-1"><strong>Gender</strong></p>
              <p>Mr. Jigar Pankajbhai Barot</p>
            </div>
            <div class="col-12 col-md-4 col-lg-3 col-xl-2">
              <p class="mb-1"><strong>Contact Number</strong></p>
              <p>05-Jun-1988</p>
            </div>
            <div class="col-12 col-md-4 col-lg-3 col-xl-3">
              <p class="mb-1"><strong>Occupation</strong></p>
              <p><a href="mailto:test@gmail.com" class="orangetext">test@gmail.com</a></p>
            </div>
            <div class="col-12 col-md-4 col-lg-3 col-xl-4">
              <p class="mb-1"><strong>Registration Address</strong></p>
              <p>E-101, Ariane Casa, Adalaj, GUJARAT-382421</p>
            </div>
          </div>
        </div>
        <h3 class="orangetext">Vehicle Details</h3>
        <div class="bdr p-3 mb-3 ">
          <div class="row">
            <div class="col-12 col-md-4 col-lg-3">
              <p class="mb-1"><strong>Policy Start Date</strong></p>
              <p>Mr. Jigar Pankajbhai Barot</p>
            </div>
            <div class="col-12 col-md-4 col-lg-3 col-xl-2">
              <p class="mb-1"><strong>Registration Number</strong></p>
              <p>45645645665</p>
            </div>
            <div class="col-12 col-md-4 col-lg-3 col-xl-3">
              <p class="mb-1"><strong>Purchase Date</strong></p>
              <p><a href="mailto:test@gmail.com" class="orangetext">test@gmail.com</a></p>
            </div>
            <div class="col-12 col-md-4 col-lg-3 col-xl-4">
              <p class="mb-1"><strong>Customer Type</strong></p>
              <p>Individual</p>
            </div>
            <div class="col-12 col-md-4 col-lg-3">
              <p class="mb-1"><strong>Policy End Date</strong></p>
              <p>Mr. Jigar Pankajbhai Barot</p>
            </div>
            <div class="col-12 col-md-4 col-lg-3 col-xl-2">
              <p class="mb-1"><strong>Registration Date</strong></p>
              <p>05-Jun-1988</p>
            </div>
            <div class="col-12 col-md-4 col-lg-3 col-xl-3">
              <p class="mb-1"><strong>Vehicle Model</strong></p>
              <p><a href="mailto:test@gmail.com" class="orangetext">test@gmail.com</a></p>
            </div>
            <div class="col-12 col-md-4 col-lg-3 col-xl-4">
              <p class="mb-1"><strong>Previous Policy Number</strong></p>
              <p>11222212121212</p>
            </div>
            <div class="col-12 col-md-4 col-lg-3">
              <p class="mb-1"><strong>Previous Policy Expiry Date</strong></p>
              <p>04-Feb 2021</p>
            </div>
            <div class="col-12 col-md-4 col-lg-3 col-xl-2">
              <p class="mb-1"><strong>Previous Insurance</strong></p>
              <p>Bharti Axa</p>
            </div>
            <div class="col-12 col-md-4 col-lg-3 col-xl-3">
              <p class="mb-1"><strong>Engine Number</strong></p>
              <p><a href="mailto:test@gmail.com" class="orangetext">test@gmail.com</a></p>
            </div>
            <div class="col-12 col-md-4 col-lg-3 col-xl-4">
              <p class="mb-1"><strong>Chasis Number</strong></p>
              <p>891555452</p>
            </div>
            <div class="col-12 col-md-4 col-lg-3">
              <p class="mb-1"><strong>Is your vehicle on loan?</strong></p>
              <p>Yes</p>
            </div>
          </div>
        </div>
        <div class="row d-flex">
          <div class="col-md-6 ">
            <h3 class="orangetext">Policy Holder Details</h3>
            <div class="bdr p-3 mb-3  ">
              <div class="row">
                <div class="col-md-6">
                  <p class="mb-1"><strong>Name</strong></p>
                  <p>xyz</p>
                </div>
                <div class="col-md-6">
                  <p class="mb-1"><strong>Relation</strong></p>
                  <p>xyz</p>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <p class="mb-1"><strong>Gender</strong></p>
                  <p>xyz</p>
                </div>
                <div class="col-md-6">
                  <p class="mb-1"><strong>Birth Date</strong></p>
                  <p>xyz</p>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-6  ">
            <h3 class="orangetext">Premium Details</h3>
            <div class="bdr p-3 mb-3 ">
              <div class="row">
                <div class="col-12 col-xl-6">
                  <p class="mb-1"><strong>Quotation Number</strong></p>
                  <p>VT2020040911012023</p>
                </div>
                <div class="col-12 col-md-6 col-xl-3">
                  <p class="mb-1"><strong>Premium Year</strong></p>
                  <p>11</p>
                </div>

                <div class="col-12 col-md-6 col-xl-3">
                  <p class="mb-1"><strong>GST</strong></p>
                  <p>432</p>
                </div>

              </div>

              <div class="row">
                <div class="col-12 col-xl-6">
                  <p class="mb-1"><strong>IDV</strong></p>
                  <p>222</p>
                </div>
                <div class="col-md-6 col-xl-3">
                  <p class="mb-1"><strong>Net Premium</strong></p>
                  <p>11</p>
                </div>

                <div class="col-md-6 col-xl-3">
                  <p class="mb-1"><strong>Final Premium</strong></p>
                  <p>432</p>
                </div>

              </div>

            </div>
          </div>

          <div class="col-md-12">

            <h3 class="orangetext">Payment Details</h3>
            <div class=" mb-3 forcustom">
              <p class="mb-1 "><strong>Payment Mode</strong></p>
              <div class="custom-control custom-radio mb-2 custom-control-inline">
                <input type="radio" id="customRadio11" name="customRadio" class="custom-control-input"
                  ng-click="ShowPassport('N')"/>
                <label class="custom-control-label " for="customRadio11">Credit / Debit Card</label>
              </div>

              <div class="custom-control custom-radio mb-2 custom-control-inline">
                <input type="radio" id="customRadio11" name="customRadio" class="custom-control-input"
                  ng-click="ShowPassport('N')"/>
                <label class="custom-control-label " for="customRadio11">Net Banking</label>
              </div>

              <div class="row">
                <div class="col-auto">
                  <div class="form-group">
                    <label class="font-weight-bold">Mobile Number</label>
                    <input type="text" class="form-control inputtext" placeholder=" " />

                  </div>
                </div>

              </div>

              <div class="custom-control custom-radio mb-3">
                <input type="radio" class="custom-control-input" id="customCheck2"/>
                <label class="custom-control-label" for="customCheck2">Forward Payment to Client?</label>
              </div>

              <div class="row">
                <div class="col-auto">
                  <div class="form-group">
                    <label class="font-weight-bold">Email Address <span class="text-danger"> *</span></label>
                    <input type="text" class="form-control inputtext" placeholder=" " />

                  </div>
                </div>

              </div>



            </div>

          </div>
        </div>
      </div>
    </div>


    <div class="row">
      <div class="col-12">
        <h4 class="probusbluetext mb-3 mt-2 orangetext">I understand that </h4>
        <ul class="disc">
          <li>My premium is derived on the basis of information filled by me, which includes my
            previous
            year policy details and No claim Bonus Discount %, if any.</li>
          <li>RELIANCE GENERAL INSURANCE may verify my previous year policy details and may hold claim
            settlement process till the time confirmation is received from previous insurer.</li>
          <li>The Company shall have no liability under this insurance contract if it is found that
            any
            of my / our statement on particulars or declaration (other than NCB discount) in this
            proposal form or other documents are incorrect and / or untrue / false.</li>
          <li>If any discrepancy found in the information provided for arriving at NCB discount %,
            Company shall communicate to me via e-mail &/ or letter for payment of the balance premium
            amount within 20 days from the date of communication.</li>
          <li>If the balance amount is not paid by me within 20 days from the date of communication, I
            will be liable to pay three times the balance premium amount at the time of first claim
            made
            under the policy which shall be deducted from the final approved claim amount under the
            policy.</li>
        </ul>
        <div class="custom-control custom-checkbox mb-3">
          <input type="checkbox" class="custom-control-input" id="customCheck1" ng-model="ShowPassport1"/>
          <label class="custom-control-label" for="customCheck1">I hereby agree to the Terms &
            Conditions of the purchase of this policy.</label>
        </div>
        <div class="custom-control custom-checkbox mb-3">
          <input type="checkbox" class="custom-control-input" id="customCheck2"/>
          <label class="custom-control-label" for="customCheck2">Receive Service SMS and E-mail
            alerts.</label>
        </div>
      </div>
    </div>


    <div class="row">
      <div class="col-12 text-center">
    <Link to ="/HealthPayment">

        <button class="btn orangebtn mb-3"> Make Payment </button>
  </Link>
      </div>

    </div>

  </div>
</div>

</div>
    </>
  )
}

export default HealthRaviewPay