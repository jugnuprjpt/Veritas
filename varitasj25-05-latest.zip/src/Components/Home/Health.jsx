import React from 'react'
import Main from '../Main/Main.jsx'



const Health = () => {
  return (
    <>
    <Main></Main>
    
    </>
  )
}

export default Health
