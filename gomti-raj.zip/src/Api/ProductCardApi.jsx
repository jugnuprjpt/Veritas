import React from 'react'
import fiftenkg from '../img/fiftenkg.jpeg'
import fourkg from '../img/fourkg.png'

const ProductCardApi = [
    { id: 1, image: fiftenkg, title: "Pure filterd Oil-15kg", description:"filterd olil with vitamin A and Vitamen D" , price:2900,amount: 1},
    { id: 2, image: fourkg, title: "Pure filterd Oil-5kg", description:"filterd olil with vitamin A and Vitamen D", price:900,amount: 1},
    /* { id: 3, image: fiftenkg, title: "Huge Savings", description:"On order above Rs 1000 only" ,price:50,amount: 1},
    { id: 4, image: fiftenkg, title: "Easy Returns", description:"On order above Rs 1000 only" ,price:50,amount: 1}, */
    
  ];

export default ProductCardApi