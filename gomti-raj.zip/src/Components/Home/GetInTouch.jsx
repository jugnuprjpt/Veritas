import React from 'react'
import Contact from '../Contact/Contact'

const GetInTouch = () => {
  return (
    <>
        <Contact></Contact>
    </>
  )
}

export default GetInTouch