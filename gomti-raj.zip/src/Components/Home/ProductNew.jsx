import React from 'react'
import Trolly from '../ProductCard/Trolly'


const ProductNew = () => {
  return (
    <>
      <Trolly></Trolly>
    </>
  )
}

export default ProductNew