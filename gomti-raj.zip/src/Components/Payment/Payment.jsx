import React from 'react'

const Payment = () => {
  return (
    <>
    
     
      
      <img src="../img/QrCode.png" alt="" />
      <a href="">Case On delhivery</a>
      
    </>
  )
}

export default Payment