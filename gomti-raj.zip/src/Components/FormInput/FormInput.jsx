import React from 'react'
import { Link } from 'react-router-dom'

const FormInput = () => {
  return (
    <>
      


        {/* <form action="" method="get"> */}
        
        <div class="container">
            <div class="form-box">
                <h2>Fill your personal detail</h2>
                <div class="input-field">
                    <label for="">User name </label>
                    <input type="text" onkeyup="lengthfind(this,'userNameLengthError')"
                        onblur="checkreq(this,'userNameError')" name="Username" id="Username" required
                        placeholder="Enter your fullname" autocomplete="off"/>
                    <small id="userNameError">This field is required</small>
                    <small id="userNameLengthError">Min 6 Max 10 char</small>
                </div>
                <div class="input-field">
                    <label for="">Email-id </label>
                    <input type="email" onkeyup="emailpattern(this,'emailPatternError')"
                        onblur="checkreq(this,'emailError')" name="Email" id="Email" required
                        placeholder="Enter your Email" autocomplete="off"/>

                    <small id="emailError">Error Msg</small>
                    <small id="emailPatternError">Invalid Email</small>
                </div>
                <div class="input-field">
                    <label for="">Mobile-number </label>
                    <input type="tel" onkeypress="return (event.which >= 48 && event.which <= 57)"
                        onblur="checkreq(this,'mobileError')" minlength="10" maxlength="10" name="Phone" required
                        id="Phone" placeholder="Enter your Mobile-number " autocomplete="off"/>
                    <small id="mobileError">Error Msg</small>
                </div>
                <div class="input-field">
                    <label for="">Address</label>
                    <textarea name="" id="" cols="50" rows="3"></textarea>
                </div>
                <div class="input-field">
                    <label for="">Product Description</label>
                    <textarea name="" id="" cols="50" rows="3"></textarea>
                </div>
                <div class="input-field">
                    <label for="">Price </label>
                    <input type="text" />
                </div>
               {/*  <div class="input-field">
                    <label for="">Password </label>
                    <input type="password" onblur="checkreq(this,'passwordError')" name="Password" required
                        id="Password" placeholder="Enter your Password" autocomplete="off"/>
                    <small id="passwordError">Error Msg</small>
                </div>
                <div class="input-field">
                    <label for="">Confirm-Password </label>
                    <input type="password" onblur="checkreq(this,'cpassError'), checkpass(this,'cpassError')"
                        name="cPassword" required id="cPassword" placeholder="Enter your Password again"
                        autocomplete="off"/>
                    <small id="cpassError">Error Msg</small>
                </div> */}
                <Link to = "/Payment">
                <input class="sub" type="submit" id="submit" value="submit"/>
                </Link>
            </div>
        </div>
    {/* </form> */}
     
    
    </>
  )
}

export default FormInput