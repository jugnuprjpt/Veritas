import React from 'react'
import dashboard from '../img/dashboard-health.png'

const ProductCardApi = [
    { id: 1, image: dashboard, title: "Free Shipping", description:"On order above Rs 1000 only" , price:50,amount: 1},
    { id: 2, image: dashboard, title: "Prime Quality", description:"On order above Rs 1000 only", price:50,amount: 1},
    { id: 3, image: dashboard, title: "Huge Savings", description:"On order above Rs 1000 only" ,price:50,amount: 1},
    { id: 4, image: dashboard, title: "Easy Returns", description:"On order above Rs 1000 only" ,price:50,amount: 1},
  
  ];

export default ProductCardApi