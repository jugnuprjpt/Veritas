import React from 'react'

const HealthProposal = () => {
  return (
    <>
         <div className="container-fluid commoncl">

<div className="row">
  <div className="col-12 health-reviewpage-bg pt-md-3 pb-md-3">

    <div className="container">
      <div className="row">
        <div className="col-md-6 col-xxl-8 whbg pt-md-3 pb-md-3 pl-xl-5 pr-xl-5 posch">
          <div className="row justify-content-between align-items-center">
            <div className="col">
              <img src="img/comp-logo/adityabirla.png" alt="" className="img-fluid mb-3" />
            </div>
            <div className="col text-right">

              <div className="d-flex flex-column premiumamount">
                <span className="orangetext"> Premium </span>
                <span className="orangetext font-weight-semi-bold">
                  <i className="fas fa-rupee-sign mr-1"></i> 25000
                </span>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-12 ">
              <p><strong> Policy Start Date : </strong> 12-Feb-2019</p>
              <p><strong> Policy End Date : </strong> 03-Feb-2021</p>
              <hr className="horizantalline" />
              <p><strong> Quotation Number : </strong> VTSBMTRPC2019070917335816</p>
              <p>
                <strong> Vehicle Model : </strong> MARUTI SWIFT DZIRE LXI (1298 cc) - PETROL
              </p>

            </div>
          </div>
        </div>
      </div>

    </div>

  </div>
</div>


<div className="container health-after-plan pt30 pb30 pl-0 pr-0 ">
  <div className="row no-gutters">
    <div className="col-12 bxcl pl-0 pr-0">


      <uib-tabset active="active" justified="true" className="fortab">
        <uib-tab index="0" heading="Proposer’s Info">
          <div className="forcard">
            <div className="p-3">
              <h4 className="mb-3 orangetext">Personal Detail</h4>
              <div className="border p-3 border-radius-10 mb-3">
              <div className="row">
                <div className="col-12 col-md-4">
                  <div className="row lesspd">
                    <div className="col-4 col-md-6 col-lg-5 col-xl-4  ">
                      <div className="form-group">
                        <label className="font-weight-bold">Salutation <sup className="text-danger">*</sup></label>
                        <select className="custom-select ">
                          <option selected>Salutation</option>
                        </select>
                      </div>
                    </div>
                    <div className="col-8  col-md-6 col-sm-8 col-lg-7  col-xl-8">
                      <label className="font-weight-bold">First Name <sup className="text-danger">*</sup> </label>
                      <div className="form-group">

                        <input type="text" className="form-control floating-input" placeholder=" " />

                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <label className="font-weight-bold">Middle Name <sup className="text-danger">*</sup> </label>
                  <div className="form-group">
                    <input type="text" className="form-control floating-input" placeholder=" " />

                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="font-weight-bold">Last Name</label>

                    <input type="text" className="form-control floating-input" placeholder=" " />



                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-md-4">
                  <div className="row lesspd">
                    <div className="col-sm-6">
                      <div className="form-group">
                        <label className="font-weight-bold">Gender</label>
                        <select className="custom-select floating-select">
                          <option selected>Select Gender</option>

                        </select>



                      </div>
                    </div>
                    <div className="col-sm-6">
                      <div className="form-group">
                        <label className="font-weight-bold">Marital Status</label>
                        <select className="custom-select floating-select">
                          <option selected>Marital Status</option>

                        </select>



                      </div>


                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="mb-3">
                    <label className="font-weight-bold">Birth Date</label>
                    <div className="input-group  dateinput flex-nowrap">

                      <input type="text" className="form-control floating-input" placeholder=" "
                        uib-datepicker-popup="{{format}}" ng-model="dt" is-open="popup1.opened"
                        datepicker-options="dateOptions" ng-required="true" close-text="Close"
                        alt-input-formats="altInputFormats"/>



                      <div className="input-group-append"> <span className="input-group-text" ng-click="open1()"><img
                            src="img/dateicon.png" alt="" /></span> </div>
                    </div>

                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="font-weight-bold">Occupation</label>
                    <select className="custom-select">
                      <option selected>Service</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="font-weight-bold">Email</label>
                    <input type="text" className="form-control " placeholder=" " />
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="font-weight-bold">Mobile Number</label>
                    <input type="text" className="form-control " placeholder="" />
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="font-weight-bold">Additional Contact Number</label>
                    <input type="text" className="form-control " placeholder=" " />
                  </div>
                </div>
              </div>

            </div>
              <h4 className="mb-3 orangetext">Address Detail</h4>

              <div className="border p-3 border-radius-10 mb-3">
              <div className="row">
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="font-weight-bold">Address 1</label>
                    <input type="text" className="form-control " placeholder=" " />
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="font-weight-bold">Address 2</label>
                    <input type="text" className="form-control " placeholder=" " />
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="font-weight-bold">Address 3</label>
                    <input type="text" className="form-control " placeholder=" " />
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="font-weight-bold">Select State</label>
                    <select className="custom-select">
                      <option selected>Select State</option>

                    </select>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="font-weight-bold">Select City</label>
                    <select className="custom-select">
                      <option selected>Select City</option>

                    </select>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="font-weight-bold">Pincode</label>
                    <input type="text" className="form-control " placeholder=" " />
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="font-weight-bold">Pan Card </label>
                    <input type="text" className="form-control " placeholder=" " />
                  </div>
                </div>
                <div className="col-md-4">
                  <label className="font-weight-bold"> GSTIN </label>
                  <div className="form-group">
                    <input type="text" className="form-control " placeholder="GSTIN" />
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="font-weight-bold"> Aadhaar No. </label>
                    <input type="text" className="form-control " placeholder=" " />
                  </div>
                </div>

                <div className="col-md-4">
                  <div className="form-group">
                    <label className="font-weight-bold"> Fasttag  <small> <strong> (Mandatory for Digit) </strong> </small> </label>
                    <input type="text" className="form-control " placeholder=" " />
                    <small> <strong> (Mandatory for Digit) </strong> </small>
                  </div>
                </div>

              </div>
              <div className="row">
                <div className="col-12">
                  <p><strong>Registration address is same as above.</strong></p>
                  <div className="pb-2">
                    <div className="custom-control custom-radio custom-control-inline">
                      <input type="radio" className="custom-control-input" name="customRadio" id="customRadio11"/>
                      <label className="custom-control-label" for="customRadio11">Yes</label>
                    </div>
                    <div className="custom-control custom-radio custom-control-inline">
                      <input type="radio" className="custom-control-input" name="customRadio" id="customRadio22"
                        checked/>
                      <label className="custom-control-label" for="customRadio22">No</label>
                    </div>
                  </div>
                </div>
              </div> </div>
            </div>
            <div className="pt10 pb15 text-center position-relative"> 
              <a href="#">
                <img src="img/back.png" alt=" " className="img-fluid backbtn"  />
              </a>
              <a href="#" className="btn orangebtn bigbutton"><span
                  className="next">Next</span>
              </a> </div>
          </div>
        </uib-tab>
       

        
      </uib-tabset>

    </div>
  </div>
</div>

</div>
    </>
  )
}

export default HealthProposal