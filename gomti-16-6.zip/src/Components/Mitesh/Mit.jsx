import React from 'react'

const Mit = () => {
  return (
    <>
<section class="gallery">
<h1>Our-services</h1>
<div class="container">
<div class="row">
<div class="col-md-3 " >
    <div class="gallery-box bg-primary ">
        <img src="../img/commercial-review-pay.png"/>
        <h4>Free-shiping</h4>
        
    </div>
</div> 
<div class="col-md-3">
    <div class="gallery-box bg-primary ">
    <img src="../img/commercial-review-pay.png"/>
        <h4>Prime Quality</h4>
    </div>
</div>
<div class="col-md-3">
    <div class="gallery-box bg-primary ">
    <img src="../img/commercial-review-pay.png"/>
        <h4>Huge savings</h4>
    </div>
</div>
<div class="col-md-3">
    <div class="gallery-box bg-primary ">
    <img src="../img/commercial-review-pay.png"/>
        <h4>Easy returns</h4>
    </div>
</div> 
</div>    
</div>
</section>
    </>
  )
}
export default Mit
