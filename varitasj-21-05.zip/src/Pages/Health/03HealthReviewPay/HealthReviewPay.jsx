import React from "react";
import { Link } from "react-router-dom";

const HealthReviewPay = () => {
  return (
    <>
      <div className="container-fluid commoncl health-planlist-page">
        <div className="row">
          <div className="col-12 planlistbg mb15 pt-3 pb-3">
            <div className="row">
              <div className="col-12 ">
                <div className="container plan-list-top ">
                  <div className="row align-items-center">
                    <div className="col-12 col-md mb-3">
                      <span className="orangetext ptsans bigfont">
                        Qutation Number :{" "}
                      </span>
                      VTSBMTRPC2019070917335816
                    </div>

                    <div className="col-12 col-md-auto orangetext font-weight-bold ptsans">
                      {" "}
                      #00000
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-12">
                      <ul className="d-flex healthtopdetail flex-wrap">
                        <li className="text-nowrap">
                          {" "}
                          <span className="orangetext font-weight-bold ptsans">
                            {" "}
                            Self :{" "}
                          </span>{" "}
                          32 Year
                        </li>
                        <li className="text-nowrap">
                          <span className="orangetext font-weight-bold ptsans">
                            {" "}
                            Spous :{" "}
                          </span>{" "}
                          32 Year
                        </li>
                        <li className="text-nowrap">
                          <span className="orangetext font-weight-bold ptsans">
                            {" "}
                            Son:{" "}
                          </span>{" "}
                          32 Year
                        </li>
                        <li className="text-nowrap">
                          <span className="orangetext font-weight-bold ptsans">
                            {" "}
                            Daughter :{" "}
                          </span>{" "}
                          2 Year
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-12 pt-2 pb-2  ">
                      <div className="row justify-content-between flex-lg-wrap">
                        <div className="col-12 col-xl">
                          <div className="row">
                            <div className="col-xl">
                              <div className="row">
                                <div className="col-auto">
                                  <span className="orangetext font-weight-bold ptsans">
                                    Insurance Company :
                                  </span>
                                </div>
                                <div className="col">
                                  <div className="forcustom">
                                    <div className="custom-control custom-checkbox custom-control-inline">
                                      <input
                                        type="checkbox"
                                        className="custom-control-input"
                                        id="customCheck1"
                                      />
                                      <label
                                        className="custom-control-label"
                                        for="customCheck1"
                                      >
                                        IFFCOTOKIO
                                      </label>
                                    </div>
                                    <div className="custom-control custom-checkbox custom-control-inline">
                                      <input
                                        type="checkbox"
                                        className="custom-control-input"
                                        id="customCheck11"
                                      />
                                      <label
                                        className="custom-control-label"
                                        for="customCheck11"
                                      >
                                        TATA
                                      </label>
                                    </div>
                                    <div className="custom-control custom-checkbox custom-control-inline">
                                      <input
                                        type="checkbox"
                                        className="custom-control-input"
                                        id="customCheck22"
                                      />
                                      <label
                                        className="custom-control-label"
                                        for="customCheck22"
                                      >
                                        NEWINDIA
                                      </label>
                                    </div>
                                  </div>
                                </div>
                              </div>

                              <span></span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-12 ">
            <div className="container">
              <div className="row">
                <div className="col-12 text-right d-flex justify-content-between">
                  <a href="#" className="orangetext">
                    <i className="fas fa-angle-double-left "></i> Back
                  </a>

                  <span>
                    Showing <span>88</span> Result
                  </span>
                </div>
              </div>
              <div className="row">
                <div className="col-12 mb-1 mt-1">
                  {/*  <uib-progressbar value="55" striped="true"></uib-progressbar> */}
                </div>
              </div>
              <div className="row col-12">
                <div className="row planlist-row">
                  <div className="col-lg-auto   leftside menusidebar ">
                    <div className="lightbackground pb-3">
                      <div className="icon-menu  d-xs-block d-sm-block d-lg-none">
                        {" "}
                        <i className="fas fa-sliders-h"></i>
                      </div>
                      <div className="panel-default openpanel">
                        <div className="panel-heading dark-blue">
                          <h4 className="panel-title mb-0">Sum Assured </h4>
                        </div>
                        <div className="panel-body planlistbg font12">
                          <select className="custom-select ">
                            <option selected>3 Lakhs</option>
                          </select>
                        </div>
                      </div>
                      <div className="panel-default openpanel">
                        <div className="panel-heading dark-blue">
                          <h4 className="panel-title mb-0">Tenure Year </h4>
                        </div>
                        <div className="panel-body planlistbg font12">
                          <div className="btn-group mb-3">
                            <label
                              className="btn generalbtn"
                              ng-model="radioModel"
                              uib-btn-radio="'one'"
                              uncheckable
                            >
                              {" "}
                              1
                            </label>
                            <label
                              className="btn generalbtn"
                              ng-model="radioModel"
                              uib-btn-radio="'two'"
                              uncheckable
                            >
                              2
                            </label>
                            <label
                              className="btn generalbtn"
                              ng-model="radioModel"
                              uib-btn-radio="'three'"
                              uncheckable
                            >
                              3
                            </label>
                          </div>
                        </div>
                      </div>

                      <div className="panel-default openpanel">
                        <div className="panel-heading dark-blue">
                          <h4 className="panel-title mb-0">Policy Type </h4>
                        </div>
                        <div className="panel-body planlistbg font12">
                          <div className="btn-group btngp mb-3">
                            <label
                              className="btn   mb-0"
                              ng-model="radioModel11"
                              uib-btn-radio="'Left'"
                              uncheckable
                            >
                              Basic
                            </label>
                            <label
                              className="btn   mb-0"
                              ng-model="radioModel11"
                              uib-btn-radio="'Middle'"
                              uncheckable
                            >
                              Super Top-Up
                            </label>
                          </div>
                          <select className="custom-select ">
                            <option selected>Deductible Amount</option>
                          </select>
                        </div>
                      </div>

                      {/*   <uib-accordion close-others="oneAtATime" className="lefttoggle"> */}

                      <div
                        uib-accordion-group
                        className="panel-default"
                        is-open="status2.open"
                      >
                        {/* <uib-accordion-heading> Discount <i className="pull-right fa ico"
                        ng-className="{'fa-minus': status2.open, 'fa-plus': !status2.open}"></i> </uib-accordion-heading> */}
                        <div className="custom-control custom-checkbox mb-3">
                          <input
                            type="checkbox"
                            className="custom-control-input"
                            id="customCheck1"
                            ng-model="ShowPassport1"
                          />
                          <label
                            className="custom-control-label"
                            for="customCheck1"
                          >
                            Restore Benefits
                          </label>
                        </div>
                        <div className="custom-control custom-checkbox mb-3">
                          <input
                            type="checkbox"
                            className="custom-control-input"
                            id="customCheck2"
                          />
                          <label
                            className="custom-control-label"
                            for="customCheck2"
                          >
                            Critical Illness
                          </label>
                        </div>

                        <div className="custom-control custom-checkbox mb-3">
                          <input
                            type="checkbox"
                            className="custom-control-input"
                            id="customCheck2"
                          />
                          <label
                            className="custom-control-label"
                            for="customCheck2"
                          >
                            Maternity Cover
                          </label>
                        </div>

                        <div className="custom-control custom-checkbox mb-3">
                          <input
                            type="checkbox"
                            className="custom-control-input"
                            id="customCheck2"
                          />
                          <label
                            className="custom-control-label"
                            for="customCheck2"
                          >
                            Personal Accident
                          </label>
                        </div>
                      </div>
                      {/*  </uib-accordion> */}
                      <div className="text-center pt-2 pb-2">
                        <button className="btn recalculatebtn  pl25 pr25 ">
                          Re-Calculates Quote
                        </button>
                      </div>
                    </div>
                  </div>
                  <div className="col-lg righside">
                    <div className="row d-none d-md-block">
                      <div className="col-sm-12">
                        <div className="shadow  mb-4  topbar">
                          <div className="row justify-content-between align-center ">
                            <div className="col-sm-auto d-flex align-items-center">
                              {" "}
                              <a
                                href="#"
                                className="dflex align-center"
                                ng-click="editpop()"
                              >
                                <img
                                  src="img/editimg.png"
                                  alt=""
                                  className="pr10"
                                />
                                Edit Details
                              </a>{" "}
                            </div>
                            <div className="col-sm-auto d-flex align-items-center">
                              {" "}
                              <a
                                href="#"
                                className="dflex align-center"
                                ng-click="emailpop()"
                              >
                                <img
                                  src="img/share.png"
                                  alt=""
                                  className="pr10 sharequotes"
                                />
                                Share Quote(s)
                              </a>
                            </div>

                            <div className="col-sm-auto">
                              <select className="custom-select allcl">
                                <option selected>All</option>
                                <option value="1">Top3</option>
                                <option value="2">Veritas Prefered</option>
                              </select>
                            </div>

                            <div className="col-sm-auto d-flex">
                              <label className="mb-0 mt-2 pr-2">
                                {" "}
                                <img src="img/filter.png" alt="" /> Filter
                              </label>
                              <div className="showres premium-sorting text-md-right text-lg-right  text-sm-right">
                                <select className="custom-select">
                                  <option selected>Low to High</option>
                                  <option selected>High to Low</option>
                                </select>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-sm-12">
                        <div className="row planlist-row pb-4">
                          <div className="col-12 col-md-6 col-lg-4 col-xl-3  mb-4">
                            <div className="boxdivchild text-center ">
                              <div className="text-center logocontainer">
                                {" "}
                                <img
                                  src="img/comp-logo/acko.png"
                                  alt=""
                                  className="img-fluid"
                                />{" "}
                              </div>
                              <p className="protitle font-weight-bold">
                                dsfsdfsfjhsgjh hgsffjhfgjhsdgj gsdfgsfgfgj
                              </p>

                              <p>Cashless Treatment Available at</p>
                              <a
                                href="#"
                                className="orangetext font-weight-bold d-flex align-items-center justify-content-center"
                                ng-click="hospitallist()"
                              >
                                <img
                                  src="img/hospital-area.png"
                                  alt=""
                                  className="mr-2"
                                />
                                <span> Hospital in your area </span>
                              </a>
                              <Link to="/">
                                <a
                                  href="#"
                                  className="carbtn mt10 d-inline-block"
                                >
                                  {" "}
                                  &#8377; 3,478{" "}
                                  <img
                                    src="img/cart.png"
                                    alt=""
                                    className="cartimg"
                                  />
                                </a>
                              </Link>
                              <div>
                                <small>Including GST</small>
                              </div>

                              <div className="mb-2 detaillinks">
                                <a
                                  href="#"
                                  className="orangetext"
                                  ng-click="premiumbreakup()"
                                >
                                  Plan Detail
                                </a>{" "}
                                <a href="#" className="orangetext">
                                  Policy Wording
                                </a>{" "}
                                <a href="#" className="orangetext">
                                  Policy Wording
                                </a>
                              </div>

                              <div className="pt-2">
                                <a
                                  href="#"
                                  className="orangetext pl5 pr5"
                                  ng-click="openModal()"
                                >
                                  Premium Breakup
                                </a>
                              </div>
                              <div className="plan-det mb-3">
                                <div className="compareproduct greencheckbox mb-2">
                                  <div className="custom-control-container d-inline-block">
                                    <div className="custom-control custom-checkbox  custom-control-inline  pl-0 pr-3">
                                      <input
                                        type="checkbox"
                                        className="custom-control-input"
                                        id="customCheck222"
                                      />
                                      <label
                                        className="custom-control-label orangetext"
                                        for="customCheck222"
                                      >
                                        Compare Products
                                      </label>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>

                            {/* <div className="pl15 pr15">
                          <div className="row mb-2">
                            <div className="col col-md-6 text-left">Basic Price</span> </div>
                            <div className="col col-md-6 text-right"> <i className="fa fa-rupee"></i> 3229 </div>
                          </div>
                          <div className="row mb-2">
                            <div className="col col-md-6 text-left">24x7 Roadside Assistance </span> </div>
                            <div className="col col-md-6 text-right"> <i className="fa fa-rupee"></i>249</div>
                          </div>

                          <div className="row mb-2">
                            <div className="col col-md-6 text-left greytext">Engine Protector </span> </div>
                            <div className="col col-md-6 text-right greytext">NA</div>
                          </div>
                          <div className="row mb-2">
                            <div className="col col-md-6 text-left greytext">NCB Protection </span> </div>
                            <div className="col col-md-6 text-right greytext">NA</div>
                          </div>

                        </div>
                      </div>
                    </div>
                    <div className="col-12 col-md-6 col-lg-4 col-xl-3  mb-4">
                      <div className="boxdivchild text-center ">
                        <div className="text-center logocontainer"> <img src="img/comp-logo/acko.png" alt=""
                            className="img-fluid" /> </div>
                        <p className="protitle font-weight-bold">
                          dsfsdfsfjhsgjh hgsffjhfgjhsdgj gsdfgsfgfgj
                        </p>

                        <p>
                          Cashless Treatment Available at
                        </p>
                        <a href="#" className="orangetext font-weight-bold d-flex align-items-center justify-content-center"
                          ng-click="hospitallist()">
                          <img src="img/hospital-area.png" alt="" className="mr-2" />
                          <span> Hospital in your area </span>
                        </a>

                        <a href="#" className="carbtn mt10 d-inline-block"> &#8377; 3,478 <img src="img/cart.png" alt=""
                            className="cartimg" /></a>
                        <div>
                          <small>Including GST</small>
                        </div>

                        <div className="mb-2 detaillinks">
                          <a href="#" className="orangetext" ng-click="premiumbreakup()">Plan Detail</a> <a href="#"
                            className="orangetext">Policy
                            Wording</a> <a href="#" className="orangetext">Policy Wording</a>

                        </div>

                     <div className="pt-2">
                          <a href="#" className="orangetext pl5 pr5" ng-click="openModal()">Premium Breakup</a>
                        </div> 
                        <div className="plan-det mb-3">
                          <div className="compareproduct greencheckbox mb-2">
                            <div className="custom-control-container d-inline-block">
                              <div className="custom-control custom-checkbox  custom-control-inline  pl-0 pr-3">
                                <input type="checkbox" className="custom-control-input" id="customCheck222"/>
                                <label className="custom-control-label orangetext" for="customCheck222">Compare
                                  Products</label>
                              </div>
                            </div>
                          </div>
                        </div> */}

                            {/* <div className="pl15 pr15">
                          <div className="row mb-2">
                            <div className="col col-md-6 text-left">Basic Price</span> </div>
                            <div className="col col-md-6 text-right"> <i className="fa fa-rupee"></i> 3229 </div>
                          </div>
                          <div className="row mb-2">
                            <div className="col col-md-6 text-left">24x7 Roadside Assistance </span> </div>
                            <div className="col col-md-6 text-right"> <i className="fa fa-rupee"></i>249</div>
                          </div>

                          <div className="row mb-2">
                            <div className="col col-md-6 text-left greytext">Engine Protector </span> </div>
                            <div className="col col-md-6 text-right greytext">NA</div>
                          </div>
                          <div className="row mb-2">
                            <div className="col col-md-6 text-left greytext">NCB Protection </span> </div>
                            <div className="col col-md-6 text-right greytext">NA</div>
                          </div>

                        </div>
                      </div>
                    </div>
                    <div className="col-12 col-md-6 col-lg-4 col-xl-3  mb-4">
                      <div className="boxdivchild text-center ">
                        <div className="text-center logocontainer"> <img src="img/comp-logo/acko.png" alt=""
                            className="img-fluid" /> </div>
                        <p className="protitle font-weight-bold">
                          dsfsdfsfjhsgjh hgsffjhfgjhsdgj gsdfgsfgfgj
                        </p>

                        <p>
                          Cashless Treatment Available at
                        </p>
                        <a href="#" className="orangetext font-weight-bold d-flex align-items-center justify-content-center"
                          ng-click="hospitallist()">
                          <img src="img/hospital-area.png" alt="" className="mr-2" />
                          <span> Hospital in your area </span>
                        </a>

                        <a href="#" className="carbtn mt10 d-inline-block"> &#8377; 3,478 <img src="img/cart.png" alt=""
                            className="cartimg" /></a>
                        <div>
                          <small>Including GST</small>
                        </div>

                        <div className="mb-2 detaillinks">
                          <a href="#" className="orangetext" ng-click="premiumbreakup()">Plan Detail</a> <a href="#"
                            className="orangetext">Policy
                            Wording</a> <a href="#" className="orangetext">Policy Wording</a>

                        </div>

                         <div className="pt-2">
                          <a href="#" className="orangetext pl5 pr5" ng-click="openModal()">Premium Breakup</a>
                        </div> 
                        <div className="plan-det mb-3">
                          <div className="compareproduct greencheckbox mb-2">
                            <div className="custom-control-container d-inline-block">
                              <div className="custom-control custom-checkbox  custom-control-inline  pl-0 pr-3">
                                <input type="checkbox" className="custom-control-input" id="customCheck222"/>
                                <label className="custom-control-label orangetext" for="customCheck222">Compare
                                  Products</label>
                              </div>
                            </div>
                          </div>
                        </div>

 */}
                            {/*    <div className="pl15 pr15">
                          <div className="row mb-2">
                            <div className="col col-md-6 text-left">Basic Price</span> </div>
                            <div className="col col-md-6 text-right"> <i className="fa fa-rupee"></i> 3229 </div>
                          </div>
                          <div className="row mb-2">
                            <div className="col col-md-6 text-left">24x7 Roadside Assistance </span> </div>
                            <div className="col col-md-6 text-right"> <i className="fa fa-rupee"></i>249</div>
                          </div>

                          <div className="row mb-2">
                            <div className="col col-md-6 text-left greytext">Engine Protector </span> </div>
                            <div className="col col-md-6 text-right greytext">NA</div>
                          </div>
                          <div className="row mb-2">
                            <div className="col col-md-6 text-left greytext">NCB Protection </span> </div>
                            <div className="col col-md-6 text-right greytext">NA</div>
                          </div>

                        </div>
                      </div>
                    </div> */}
                            {/*  <div className="col-12 col-md-6 col-lg-4 col-xl-3  mb-4">
                      <div className="boxdivchild text-center ">
                        <div className="text-center logocontainer"> <img src="img/comp-logo/acko.png" alt=""
                            className="img-fluid" /> </div>
                        <p className="protitle font-weight-bold">
                          dsfsdfsfjhsgjh hgsffjhfgjhsdgj gsdfgsfgfgj
                        </p>

                        <p>
                          Cashless Treatment Available at
                        </p>
                        <a href="#" className="orangetext font-weight-bold d-flex align-items-center justify-content-center"
                          ng-click="hospitallist()">
                          <img src="img/hospital-area.png" alt="" className="mr-2" />
                          <span> Hospital in your area </span>
                        </a>

                        <a href="#" className="carbtn mt10 d-inline-block"> &#8377; 3,478 <img src="img/cart.png" alt=""
                            className="cartimg" /></a>
                        <div>
                          <small>Including GST</small>
                        </div>

                        <div className="mb-2 detaillinks">
                          <a href="#" className="orangetext" ng-click="premiumbreakup()">Plan Detail</a> <a href="#"
                            className="orangetext">Policy
                            Wording</a> <a href="#" className="orangetext">Policy Wording</a>

                        </div>

                         <div className="pt-2">
                          <a href="#" className="orangetext pl5 pr5" ng-click="openModal()">Premium Breakup</a>
                        </div> 
                        <div className="plan-det mb-3">
                          <div className="compareproduct greencheckbox mb-2">
                            <div className="custom-control-container d-inline-block">
                              <div className="custom-control custom-checkbox  custom-control-inline  pl-0 pr-3">
                                <input type="checkbox" className="custom-control-input" id="customCheck222">
                                <label className="custom-control-label orangetext" for="customCheck222">Compare
                                  Products</label>
                              </div>
                            </div>
                          </div>
                        </div>


                        <div className="pl15 pr15">
                          <div className="row mb-2">
                            <div className="col col-md-6 text-left">Basic Price</span> </div>
                            <div className="col col-md-6 text-right"> <i className="fa fa-rupee"></i> 3229 </div>
                          </div>
                          <div className="row mb-2">
                            <div className="col col-md-6 text-left">24x7 Roadside Assistance </span> </div>
                            <div className="col col-md-6 text-right"> <i className="fa fa-rupee"></i>249</div>
                          </div>

                          <div className="row mb-2">
                            <div className="col col-md-6 text-left greytext">Engine Protector </span> </div>
                            <div className="col col-md-6 text-right greytext">NA</div>
                          </div>
                          <div className="row mb-2">
                            <div className="col col-md-6 text-left greytext">NCB Protection </span> </div>
                            <div className="col col-md-6 text-right greytext">NA</div>
                      </div>
 
                        </div>
                      </div>
                    </div>  */}

                            {/* <div className="col-12 col-md-6 col-lg-4 col-xl-3  mb-4">
                      <div className="boxdivchild text-center ">
                        <div className="text-center logocontainer"> <img src="img/comp-logo/acko.png" alt=""
                            className="img-fluid" /> </div>
                        <p className="protitle font-weight-bold">
                          dsfsdfsfjhsgjh hgsffjhfgjhsdgj gsdfgsfgfgj
                        </p>

                        <p>
                          Cashless Treatment Available at
                        </p>
                        <a href="#" className="orangetext font-weight-bold d-flex align-items-center justify-content-center"
                          ng-click="hospitallist()">
                          <img src="img/hospital-area.png" alt="" className="mr-2" />
                          <span> Hospital in your area </span>
                        </a>

                        <a href="#" className="carbtn mt10 d-inline-block"> &#8377; 3,478 <img src="img/cart.png" alt=""
                            className="cartimg" /></a>
                        <div>
                          <small>Including GST</small>
                        </div>

                        <div className="mb-2 detaillinks">
                          <a href="#" className="orangetext" ng-click="premiumbreakup()">Plan Detail</a> <a href="#"
                            className="orangetext">Policy
                            Wording</a> <a href="#" className="orangetext">Policy Wording</a>

                        </div>

                     <div className="pt-2">
                          <a href="#" className="orangetext pl5 pr5" ng-click="openModal()">Premium Breakup</a>
                        </div> 
                        <div className="plan-det mb-3">
                          <div className="compareproduct greencheckbox mb-2">
                            <div className="custom-control-container d-inline-block">
                              <div className="custom-control custom-checkbox  custom-control-inline  pl-0 pr-3">
                                <input type="checkbox" className="custom-control-input" id="customCheck222">
                                <label className="custom-control-label orangetext" for="customCheck222">Compare
                                  Products</label>
                              </div>
                            </div>
                          </div>
                        </div>


                        <div className="pl15 pr15">
                          <div className="row mb-2">
                            <div className="col col-md-6 text-left">Basic Price</span> </div>
                            <div className="col col-md-6 text-right"> <i className="fa fa-rupee"></i> 3229 </div>
                          </div>
                          <div className="row mb-2">
                            <div className="col col-md-6 text-left">24x7 Roadside Assistance </span> </div>
                            <div className="col col-md-6 text-right"> <i className="fa fa-rupee"></i>249</div>
                          </div>

                          <div className="row mb-2">
                            <div className="col col-md-6 text-left greytext">Engine Protector </span> </div>
                            <div className="col col-md-6 text-right greytext">NA</div>
                          </div>
                          <div className="row mb-2">
                            <div className="col col-md-6 text-left greytext">NCB Protection </span> </div>
                            <div className="col col-md-6 text-right greytext">NA</div>
                          </div> */}

                            {/*     </div>
                      </div>
                    </div>

                  
                  </div>
                </div>
              </div>  */}
                            {/* <div className="row">
                <div className="col-sm-12">
                  <div className="thickwhbg"></div>
                </div>
              </div>
              <div className="row">
                <div className="col-sm-12">
                  <div className="dontgetquote pt25 pb10">
                    <p className="lightblue-text text-center orangetext ">
                      We did not get a quote from the following insurers <br />
                      Might be possible reason at insurance company's end like MMV decline or RTO restricted or some
                      technical issue.

                    </p>
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-sm-12  pb20">
                  <div className="border-top-2 pt15">
                    <div className="row sm--logos flex-wrap">
                      <div className="col-xs-6 col-sm-3">
                        <div className="whitebg shadow mb-2 d-flex justify-center"> <img src="img/comp-logo/acko.png" alt=""
                            className="img-responsive" /> </div>
                      </div>
                      <div className="col-xs-6 col-sm-3">
                        <div className="whitebg shadow mb-3 d-flex justify-center"> <img src="img/comp-logo/adityabirla.png"
                            alt="" className="img-responsive" /> </div>
                      </div>
                      <div className="col-xs-6 col-sm-3 ">
                        <div className="whitebg shadow mb-3 d-flex justify-center"> <img src="img/comp-logo/apollo.png"
                            alt="" className="img-responsive" /> </div>
                      </div>
                      <div className="col-xs-6 col-sm-3 ">
                        <div className="whitebg shadow mb-3 d-flex justify-center"> <img src="img/comp-logo/acko.png" alt=""
                            className="img-responsive" /> </div>
                      </div>
                      <div className="col-xs-6 col-sm-3 ">
                        <div className="whitebg shadow mb-3 d-flex justify-center"> <img src="img/comp-logo/bajaj.png"
                            alt="" className="img-responsive" /> </div>
                      </div>
                      <div className="col-xs-6 col-sm-3 ">
                        <div className="whitebg shadow mb-3 d-flex justify-center"> <img src="img/comp-logo/bharti.png"
                            alt="" className="img-responsive" /> </div>
                      </div>
                      <div className="col-xs-6 col-sm-3 ">
                        <div className="whitebg shadow mb-3 d-flex justify-center"><img src="img/comp-logo/coco.png" alt=""
                            className="img-responsive" /> </div>
                      </div>
                      <div className="col-xs-6 col-sm-3 ">
                        <div className="whitebg shadow mb-3 d-flex justify-center"> <img src="img/comp-logo/digit.png"
                            alt="" className="img-responsive" /> </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div> */}
                            {/* </div>
          </div>
           </div>
    </div>
        </div>
      </div>
    </div>
  </div>  */}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default HealthReviewPay;
