import React from 'react'


const Private = () => {
  return (
    <>
 
      
    </>
  )
}

export default Private
