import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./Home/Home";
import Header from "./Header/Header";
import Health from "./Home/Health";
import Footer from "./Footer/Footer";
import HealthInsurance from "../Pages/Health/01HealthInsurance/HealthInsurance";
import HealthFamilyDetail from "../Pages/Health/02HealthFamilyDetail/HealthFamilyDetail";
import HealthReviewPay from "../Pages/Health/03HealthReviewPay/HealthReviewPay";
import Main from "./Main/Main";


function MyAppRouting() {
  return (
    <>
      <BrowserRouter>
        <Header></Header>
        
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="Health" element={<Health />}>
          </Route>
              <Route path="HealthInsurance" element={<HealthInsurance />}/>  
              <Route path="HealthFamilyDetail" element={<HealthFamilyDetail />}/>  
              <Route path="HealthReviewPay" element={<HealthReviewPay />}/>
          
        </Routes>
        
      <Footer></Footer>
      </BrowserRouter>
    </>
  );
}

export default MyAppRouting;
